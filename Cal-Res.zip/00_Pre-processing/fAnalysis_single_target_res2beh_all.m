function [beh0, res0, ...
    resX_se, resY_se, res_avg, beh_avg, ...
    idx, ...
    resX_se_l, resY_se_l, res_avg_l, beh_avg_l] = fAnalysis_single_target_res2beh_all( ...
                                                                beh_avg_pre,...
                                                                photo_fre, ...
                                                                beh_fre, ...
                                                                time_thre, ...
                                                                st_l_sec, ...
                                                                fn,...
                                                                Flag_ResTrace_Modify);


if strfind(fn,'.xlsx') > 0
    d = xlsread(fn);
else
    load(fn);
    d = dataout;
    clear dataout;
end;
n = size(d,1);
code = d(:,1);
period = d(:,2:3);
length = d(:,3)-d(:,2);
l_res = st_l_sec*photo_fre;
res = d(:,4:l_res+3);
l_beh = st_l_sec*beh_fre;
beh = d(:,l_res+4:end);

[length0,i_sort] = sort(length,'descend');
for i = 1:n
    res0(i,:) = res(i_sort(i),:);
    beh0(i,:) = beh(i_sort(i),:);
    period0(i,:) = period(i_sort(i),:);
    code0(i) = code(i_sort(i));

    l0 = round((period0(i,2)-period0(i,1))*photo_fre);
    x0 = beh_avg_pre * photo_fre + 1;
    pre_avg(i) = mean(res0(i,1:(x0-1)));
    x1 = x0-1+l0;
    if x1 > 3200
        x1 = 3200;
    end;
    event_avg(i) = mean(res0(i,x0:x1));
    if pre_avg(i)>event_avg(i)
        flag0(i) = 1;
    else
        flag0(i) = 0;
    end;
    
end;
idx0 = find(length0 >= time_thre);

if isempty(idx0) == true
    idx = 0;
else
    idx = idx0(end);
end;

% ------------- 
% 2023.07.04 add
if Flag_ResTrace_Modify == true
    xx = [1:400,2801:3200];
    xmax = 3200;
    f = 1;
    res0 = fTrace_fitting_modified(res0, xx, xmax, f); 
end;
% -------------

if idx == 1
    res_avg = res0(1:idx,:);
    res_std = zeros(1,3200);
    res_se = zeros(1,3200);
    beh_avg = beh0(1:idx,:);
elseif idx > 1
    res_avg = mean(res0(1:idx,:));
    res_std = std(res0(1:idx,:));
    res_se = res_std/sqrt(idx-1);
    beh_avg = mean(beh0(1:idx,:));
elseif idx ==0
    res_avg = zeros(1,3200);
    res_std = zeros(1,3200);
    res_se = zeros(1,3200);
    beh_avg = zeros(1,4000);   
end;
res0_se = res_avg-res_se;
res1_se = res_avg+res_se;
resX_se = [1:l_res,l_res:-1:1,1]/photo_fre;
resY_se = [res0_se,res1_se(l_res:-1:1),res0_se(1)];
x_res = [1:l_res]/photo_fre;


idx_l = idx+1;
if idx_l <= n
    beh_avg_l = mean(beh0(idx_l:end,:));
    res_avg_l = mean(res0(idx_l:end,:));
    res_std_l = std(res0(idx_l:end,:));
    res_se_l = res_std_l/sqrt(n-idx-1);
    res0_se_l = res_avg_l-res_se_l;
    res1_se_l = res_avg_l+res_se_l;
end;
resX_se_l = [1:l_res,l_res:-1:1,1]/photo_fre;
resY_se_l = [res0_se_l,res1_se_l(l_res:-1:1),res0_se_l(1)];
x_res = [1:l_res]/photo_fre;
