function [beh_stat] = fBehavior_state_statistics(fBSS_state, fBSS_thre, fBSS_d_beh, fBSS_beh_ratio_stage)

beh_len = size(fBSS_d_beh,1);
goal_s = zeros(beh_len,1);

% find interested points
stat_i = find(fBSS_d_beh == fBSS_state);
goal_s(stat_i) = 1;
[start_i, end_i] = fTime_periods_reconstruction(goal_s);

% start/end points of motion periods
len_i = end_i - start_i + 1;

len_i_ab_eq = find(len_i >= fBSS_thre);
len_i_be = find(len_i < fBSS_thre);
rec_ab_eq = zeros(beh_len,1);
rec_be = zeros(beh_len,1);
for i = len_i_ab_eq
    rec_ab_eq(start_i(i):end_i(i)) = 1; 
end;
for i = len_i_be
    rec_be(start_i(i):end_i(i)) = 1; 
end;


n = size(fBSS_beh_ratio_stage,2)-1;
% out_x_i '== 1: >= fBSS_thre'; '== 2: < fBSS_thre' 
out_sum = zeros(2,n);
out_n = zeros(2,n);
out_avg = zeros(2,n);
out_std = zeros(2,n);
out_ratio = zeros(2,n);
for i = 1:n
    x0 = fBSS_beh_ratio_stage(i) + 1;
    x1 = fBSS_beh_ratio_stage(i+1);
    
    temp_ab_eq = goal_s(x0:x1).*rec_ab_eq(x0:x1);
    [si_line, ei_line] = fTime_periods_reconstruction(temp_ab_eq);
    ll_ab_eq = ei_line - si_line + 1;
    
    temp_be = goal_s(x0:x1).*rec_be(x0:x1);
    [si_line, ei_line] = fTime_periods_reconstruction(temp_be);
    ll_be = ei_line - si_line + 1;

    out_sum(1,i) = sum(ll_ab_eq);
    out_sum(2,i) = sum(ll_be);
    if isempty(ll_ab_eq) == true 
        out_n(1,i) = 0;
    else
        out_n(1,i) = size(ll_ab_eq,2);
    end;
    if isempty(ll_be) == true
        out_n(2,i) = 0;
    else
        out_n(2,i) = size(ll_be,2);
    end;
    
    out_avg(1,i) = out_sum(1,i)/out_n(1,i);
    out_avg(2,i) = out_sum(2,i)/out_n(2,i);
    out_std(1,i) = std(ll_ab_eq);
    out_std(2,i) = std(ll_be);
    out_ratio(1,i) = sum(ll_ab_eq)/(x1-x0+1);
    out_ratio(2,i) = sum(ll_be)/(x1-x0+1);
end;

beh_stat = [out_sum, out_ratio, out_n, out_avg, out_std];    
    
    

        
        