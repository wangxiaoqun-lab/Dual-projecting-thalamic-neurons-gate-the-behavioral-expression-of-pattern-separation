function [z_val,dx,dummy_avg_secp,cell_avg_secp] = fCaculation_Zscore(trace_1xN, ...
                    event_x0, ...
                    pre_sec, ...
                    post_sec, ...
                    frequency, ...
                    repeat_n, ...
                    rand_flag, ...
                    filter_flag);

    
p_idx = zeros(80,frequency);
for i = 1:80
    p_idx(i,1:frequency) = (i-1)*frequency+[1:frequency];
end;

[test_n, tr_n] = size(trace_1xN);
if tr_n == 1
    tr_n = test_n;
    trace_1xN = trace_1xN';
end;
if filter_flag == 1
    filter_window = 20;             %secs
    sm_tr = smooth(trace_1xN, filter_window*frequency);
    dtr = trace_1xN-sm_tr';
elseif filter_flag == 0
    dtr = trace_1xN;
end;
if rand_flag == -1
    dx = randperm(tr_n,repeat_n);
else
    dx = rand_flag;
end;
ts = [dtr,dtr,dtr,dtr];
if size(event_x0,1) == 1
    event_x0 = event_x0';
end;
event_n = size(event_x0,1);
p0 = pre_sec * frequency;
p1 = post_sec * frequency;
p_len = p0 + p1;
tr_ex = [-p0:p1-1];
tr_idx = tr_n+event_x0 + tr_ex .* ones(event_n,p_len);


res = ts(tr_idx);
if size(res,1) > 1
    avg = mean(res);
else
    avg = res;
end;
cell_avg_secp = mean(avg(p_idx)');
dv = mean(cell_avg_secp(21:23))-mean(cell_avg_secp(11:15));
dv0 = zeros(1,repeat_n);


for i=1:repeat_n
    tr_idx0 = tr_idx + dx(i);
    res0 = ts(tr_idx0);
    if size(res0,1) > 1       
        avg0 = mean(res0);
    else
        avg0 = res0;
    end;
    avg_secp = mean(avg0(p_idx)');
    dv0(i) = mean(avg_secp(21:23))-mean(avg_secp(11:15));
    dummy_avg_secp(i,:) = avg_secp;
end;

avg_dv0 = mean(dv0);
st_dv0 = std(dv0);
z_val = (dv-avg_dv0)/st_dv0;