function data00 = fData_normalized_using_zscore(fout,d_corr,event_period,cal_f,t_offset_beh,total_length)

mPFC0 = d_corr(1).dff;
RE0 = d_corr(2).dff;
vHPC0 = d_corr(3).dff;
li0 = 1;
li1 = length(mPFC0);
ci0 = round(t_offset_beh*cal_f);
ci1 = ci0 + 720*cal_f - 1;

% dF/F
mPFC1 = mPFC0(ci0:ci1);
RE1 = RE0(ci0:ci1);
vHPC1 = vHPC0(ci0:ci1);

% Z-score little-difference
mean_mPFC1 = mean(mPFC1);
sd_mPFC1 = std(mPFC1);
mPFC2 = (mPFC1 - mean_mPFC1)/sd_mPFC1;
mean_RE1 = mean(RE1);
sd_RE1 = std(RE1);
RE2 = (RE1 - mean_RE1)/sd_RE1;
mean_vHPC1 = mean(vHPC1);
sd_vHPC1 = std(vHPC1);
vHPC2 = (vHPC1 - mean_vHPC1)/sd_vHPC1;
data_temp_out = [mean_mPFC1,sd_mPFC1,mean_vHPC1,sd_vHPC1,mean_RE1,sd_RE1]';

%
fr_beh = zeros(total_length*cal_f,1);
fr_beh_all = zeros(total_length*cal_f,1);
ep_n0 = length(event_period);
diff_ep = event_period(:,2)-event_period(:,1);
ep_ii = find(diff_ep >= 1);
yyy = [0 0 1 1 0];
trace_n = length(mPFC2);
temp = mPFC2;

for i = ep_ii'
    xxx0 = event_period(i,1);
    xxx1 = event_period(i,2);
    xxx = [xxx0,xxx1,xxx1,xxx0,xxx0]-t_offset_beh;
    ttt0 = round((xxx0-t_offset_beh)*40);
    ttt1 = round((xxx1-t_offset_beh)*40);
    fr_beh(ttt0:ttt1) = 1;
end;

all_beh_n = length(event_period);
for i = 1:all_beh_n
    xxx0 = event_period(i,1);
    xxx1 = event_period(i,2);
    xxx = [xxx0,xxx1,xxx1,xxx0,xxx0]-t_offset_beh;
    ttt0 = round((xxx0-t_offset_beh)*40);
    ttt1 = round((xxx1-t_offset_beh)*40);
    fr_beh_all(ttt0:ttt1) = 1;
end;

data00 = [mPFC2,RE2,vHPC2,fr_beh,fr_beh_all];
xlswrite(fout,data00);

[temp0, ii00] = sort(event_period(:,1));
ep00 = event_period(ii00,:);
ep01 = (ep00 - t_offset_beh) * cal_f;
fout2 = [fout(1:end-5),'_StayE_40Hz_frame.xlsx'];
xlswrite(fout2,ep01);
