function res_halfw = fDraw_target_group(target_raw0, ...
                        target_raw_n, ...
                        target_raw_sample, ...
                        target_raw_avg, ...
                        target_raw_avg_n, ...
                        target_raw_avg_sample, ...
                        s0, ...
                        s1, ...
                        photo_fre)
fn = 'Draw_target_group_output.xls';
fn2 = 'Draw_target_group_output_halfpeak.xls';
             
x0 = s0 * photo_fre + 1;
x1 = s1 * photo_fre;
xn = size(target_raw0,1);
x = [1:xn] / photo_fre;    

base_norm = zeros(target_raw_n,1);
h_norm = zeros(target_raw_n,1);                
for i = 1:target_raw_avg_n
    base0 = mean(target_raw_avg(x0:x1,i));
    h0 = max(target_raw_avg(:,i))-base0;
    base_norm(find(target_raw_sample==target_raw_avg_sample(i)))=base0;
    h_norm(find(target_raw_sample==target_raw_avg_sample(i)))=h0;
end;


for i = 1:target_raw_n
    target_raw(:,i) = (target_raw0(:,i) - base_norm(i))/h_norm(i);
end;

t_avg = mean(target_raw(:,1:target_raw_n)');
t_std = std(target_raw(:,1:target_raw_n)');
t_se = t_std/sqrt(target_raw_n-1);
t0_se = t_avg-t_se;
t1_se = t_avg+t_se;
figure;
hold on;
X_se = [1:xn,xn:-1:1,1]/photo_fre;
Y_se = [t0_se,t1_se(xn:-1:1),t0_se(1)];
patch('XData',X_se,'YData',Y_se,'FaceColor',[0.3,0.7,1],'FaceAlpha',0.3,'EdgeColor','none');
plot(x,t_avg,'Linewidth',2);
hold off
axis([0,x(end),-0.3,1.2]);

xlswrite(fn,[x',t_avg',t0_se',t1_se'],'Sheet1','A1');

for i = 1:target_raw_avg_n
    base0 = mean(target_raw_avg(x0:x1,i));
    h0 = max(target_raw_avg(:,i))-base0;
    thre0 = base0+h0/2;
    halfp0 = find(target_raw_avg(:,i)>thre0);
    diff_hp = diff(halfp0);
    hl(i,1) = size(halfp0,1);
    hl(i,2) = find([diff_hp',99]>1,1);
    hl(i,3) = target_raw_avg_sample(i);
end;

res_halfw = hl;
xlswrite(fn2,res_halfw,'Sheet1','A1');    


