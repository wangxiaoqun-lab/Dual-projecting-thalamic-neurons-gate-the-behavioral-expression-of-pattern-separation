function states = fFind_behaviour_states(d_beh, beh_fre, state_value)

s = find(d_beh == state_value);
start_p = [1,find(diff(s)>1)'+1];
n = size(start_p,2);
for i = 1:n-1
    states(i,1) = s(start_p(i));
    states(i,2) = s(start_p(i+1)-1);
end;
states(n,1) = s(start_p(n));
states(n,2) = s(end);
states = states / beh_fre;

    
    
