function ds = fFind_event_starting(d_event, event_fre, event_thre, time_start, time_interval)

xx = find(d_event > event_thre);
j = find(xx>=time_start*event_fre,1);
x0 = xx(j);
i = 1;
ds(i) = x0;
xmax = max(xx);
while x0+time_interval<xmax
    i0 = find(xx>x0+time_interval,1);
    x0 = xx(i0);
    i=i+1;
    ds(i) = x0;
end;
