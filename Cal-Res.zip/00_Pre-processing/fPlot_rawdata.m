function fout_data = fPlot_rawdata(fname, ...
                        d_corr, ...
                        d_str, ...
                        i0, ...
                        i1, ... 
                        photo_fre, ...
                        avg_pre_sec, ...
                        avg_post_sec, ...
                        avg, ...
                        d_event, ...
                        avg_event, ...
                        event_fre, ...
                        d_beh, ...
                        beh_fre, ...
                        freezing_t, ...
                        low_t, ...
                        high_t, ...
                        t_offset_beh, ...
                        ds_shock)


fm = 5;
fn = 2;
n_d_corr = size(d_corr,2);

figure('name',fname);
for j = 1:n_d_corr
    subplot(fm,fn,j*2-1);
    yy = d_corr(j).dff;
    y0 = min(yy(i0:i1));
    y1 = max(yy(i0:i1));   
    xx = d_corr(j).time;
    plot(xx(i0:i1),yy(i0:i1));
    %axis([xx(i0),xx(i1),y0,y1]);
    axis([xx(i0),xx(i1),-3,7]);    
    ylabel('dF/F');
    box off;
    title(d_str(j));
    
    subplot(fm,fn,j*2);
    hold on;
    t_l = (avg_pre_sec+avg_post_sec)*photo_fre;
    avg_x = [1:t_l]/photo_fre;
    plot(avg_x, avg(j,:));
    y0 = min(avg(j,:));
    y1 = max(avg(j,:));
    x0 = avg_pre_sec;
    x1 = (avg_pre_sec+2);
    plot([x0,x1,x1,x0,x0],[y0,y0,y1,y1,y0],'--','color',[1,0,0]);
    axis([1,avg_x(t_l),y0,y1]);
    hold off;
    box off;
    
    title([d_str{j}, ' Avg']);
end;

subplot(fm,fn,7);
hold on
for j = 1:n_d_corr
    yy = d_corr(j).dff;
    y0 = min(min(yy(i0:i1)),y0);
    y1 = max(max(yy(i0:i1)),y1);   
    xx = d_corr(j).time;
    plot(xx(i0:i1),yy(i0:i1));
end;

axis([xx(i0),xx(i1),-3,7]);
ylabel('dF/F');
box off;
title('merge');
hold off;

subplot(fm,fn,8);
hold on
for j = 1:n_d_corr
    t_l = (avg_pre_sec+avg_post_sec)*photo_fre;
    avg_x = [1:t_l]/photo_fre;
    plot(avg_x, avg(j,:));
end;
y0 = min(min(avg));
y1 = max(max(avg));
x0 = avg_pre_sec;
x1 = (avg_pre_sec+2);
plot([x0,x1,x1,x0,x0],[y0,y0,y1,y1,y0],'--','color',[1,0,0]);
axis([1,avg_x(t_l),y0,y1]);
box off;
title('merge Avg');
hold off;


subplot(fm,fn,9);
n_freezing = size(freezing_t,1);
n_low = size(low_t,1);  
n_high = size(high_t,1);
n_d_event = size(d_event,1);
n_d_beh = size(d_beh,1);
event_time = [1:n_d_event]/event_fre;
ei0 = (i0-1)*3+1;
ei1 = i1 * 3;
ey0 = min(d_event);
ey1 = max(d_event);
hold on;
plot(event_time(ei0:ei1),d_event(ei0:ei1));

for j = ds_shock
    plot([j,j+2]+t_offset_beh,[0.9,0.9],'color',[0,0,0],'Linewidth',3);
end
for j = 1:n_freezing
    plot([freezing_t(j,1),freezing_t(j,2)],[0.4,0.4],'color',[0.1,0.7,0.9],'Linewidth',3);
end 
for j = 1:n_low
    plot([low_t(j,1),low_t(j,2)],[0.6,0.6],'color',[0.1,0.9,0.5],'Linewidth',3);
end 
for j = 1:n_high
    plot([high_t(j,1),high_t(j,2)],[0.8,0.8],'color',[0.9,0.3,0.1],'Linewidth',3);
end
hold off;
axis([event_time(ei0),event_time(ei1),ey0,ey1]);
box off;
title('event');

subplot(fm,fn,10);
hold on
t_l = (avg_pre_sec+avg_post_sec)*event_fre;;
avg_x = [1:t_l]/event_fre;
plot(avg_x, avg_event);
y0 = min(avg_event);
y1 = max(avg_event);
x0 = avg_pre_sec;
x1 = (avg_pre_sec+2);
plot([x0,x1,x1,x0,x0],[y0,y0,y1,y1,y0],'--','color',[1,0,0]);
axis([1,avg_x(t_l),y0,y1]);
box off;
title('event Avg');
hold off;


fout_data = 1;