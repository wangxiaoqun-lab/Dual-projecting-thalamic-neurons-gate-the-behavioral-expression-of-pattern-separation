function [raw_out,n] = fProcess_behaviour_raw_multi(raw)
% '-1' is the flag of 'None';

raw_l = size(raw,1);
n = 0;

for i = 2:raw_l
    n = n + 1;
    raw_out(n).no = raw{i,1};
    raw_out(n).name = raw{i,2};
    
    raw_out(n).mPFC_ch = raw{i,3};
    raw_out(n).mPFC_laser = raw{i,4};
    raw_out(n).RE_ch = raw{i,5};
    raw_out(n).RE_laser = raw{i,6};
    raw_out(n).vHPC_ch = raw{i,7};
    raw_out(n).vHPC_laser = raw{i,8};
    raw_out(n).Ref_file = raw{i,9};
    raw_out(n).Event_channel = raw{i,10};
    
    raw_out(n).f_405 = raw{i,11};
    raw_out(n).f_470 = raw{i,12};
    raw_out(n).f_580 = raw{i,13};
    raw_out(n).f_event = raw{i,14};
    raw_out(n).f_learning = raw{i,15};   
    
    raw_out(n).photometry_start_marker = raw{i,16};   
    raw_out(n).fearbox_start_marker = raw{i,17};    
end;

    
    
    
    