function  d_Nphr_event = fProcessing_Nphr_event(pc_d)

ch = 5;%pc_d.Event_channel;
fn = pc_d.f_event;

d = xlsread(fn);
d_Nphr_event = d(:,ch);

