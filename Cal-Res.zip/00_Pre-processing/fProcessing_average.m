function [avg_raw, avg0] = fProcessing_average(d, ds_signal, photo_fre, avg_pre_sec, avg_post_sec);

avg_pre = avg_pre_sec*photo_fre;                      
avg_post = avg_post_sec*photo_fre;
avg_length = avg_pre+avg_post;
n = size(ds_signal,2);
avg_raw = zeros(avg_length,n);
i = 0;
dl = size(d,1);

for k = ds_signal    
    x0 = k-avg_pre;
    x1 = x0 + avg_length - 1;
    if x0 > 0
        if x1 <= dl
            i = i+1;
            avg_raw(:,i) = d(x0:x1);
        end;
    end;
end;
if n> 1 
    avg0 = mean(avg_raw');
else 
    avg0 = avg_raw;
end;
    
    