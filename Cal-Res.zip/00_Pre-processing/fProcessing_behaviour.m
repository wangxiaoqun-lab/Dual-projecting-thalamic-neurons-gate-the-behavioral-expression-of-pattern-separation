function d_beh = fProcessing_behaviour(fn,beh_fre)

Str_marker = {'FREEZING','LOW STATE','HIGH STATE'};

[d0,t0,r0] = xlsread(fn);
n_r = size(r0,1);
points = (r0{n_r,3}+r0{n_r,5}) * beh_fre;
d_beh = zeros(points,1);

for i = 2:n_r
    t0 = round(r0{i,3}*beh_fre+1);
    t1 = round((r0{i,3}+r0{i,5}) * beh_fre);
    str0 = r0{i,4};
    if strcmp(str0,Str_marker{1}) == 1
        d_beh(t0:t1) = -1;
    elseif strcmp(str0,Str_marker{2}) == 1
        d_beh(t0:t1) = 0;
    elseif strcmp(str0,Str_marker{3}) == 1
        d_beh(t0:t1) = 1;
    end;
    if t0-floor(t0)>0
        [i,r0{i,3},r0{i,5},t0,t1]
    end
end;