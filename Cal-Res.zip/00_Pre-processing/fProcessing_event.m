function d_event = fProcessing_event(pc_d)

ch = pc_d.Event_channel;
fn = pc_d.f_event;

d = xlsread(fn);
d_event = d(:,ch);