function [d_corr, d_str] = fProcessing_rawdata_FPA(pc_d,photo_fre,ch_delta)
% Usage declaration
% for Thinker fiber photometry system

% Pre-install declaration
% need FPA installed

% Calling-function declaration
% none

% General configuration.

configuration = struct();
configuration.resamplingFrequency = 40;
configuration.baselineLowpassFrequency = 1/40;
configuration.fitReference = true;%false;
configuration.baselineFitType = 'exp1'; % exp1 | poly1
configuration.lowpassFrequency = 10.0;
configuration.peakSeparation = 0.5;
%configuration.threshold = @(data) 2.0 * std(data);
configuration.peakDetectionMode = 'prominence';
configuration.peakWindow = 2.5; % Change to -2.5:0.1:2.5 for lower resolution.


% Get ref signal
laser_ref = pc_d.Ref_file;
if laser_ref == 470
    fn_ref = pc_d.f_470;
elseif laser_ref == 580
    fn_ref = pc_d.f_580;
elseif laser_ref == 405
    fn_ref = pc_d.f_405;
end;
d_ref = xlsread(fn_ref);
di = 0;

% mPFC data processing
ch = pc_d.mPFC_ch;
laser = pc_d.mPFC_laser;
if ch > 0
    if laser == 470
        fn = pc_d.f_470;
    elseif laser == 580
        fn = pc_d.f_580;
    elseif laser == 405
        fn = pc_d.f_405;
    end;
    ch_corr = ch + ch_delta;
    d = xlsread(fn);
    signal = d(:,ch_corr);
    time = [1:size(signal,1)]/photo_fre;
    time = time';    
    ref =d_ref(:,ch_corr);
    d_fpa = FPA(time, signal, ref,configuration);
    di = di + 1;
    d_corr(di) = d_fpa;
    d_str{di} = ['mPFC-',num2str(laser)];
end;
        
% RE data processing
ch = pc_d.RE_ch;
laser0 = laser;
laser = pc_d.RE_laser;
if ch > 0
    if laser == 470
        fn = pc_d.f_470;
    elseif laser == 580
        fn = pc_d.f_580;
    elseif laser == 405
        fn = pc_d.f_405;
    end;
    ch_corr = ch + ch_delta;
    if laser ~= laser0
        d = xlsread(fn);
    end;
    signal = d(:,ch_corr);
    time = [1:size(signal,1)]/photo_fre;
    time = time';    
    ref =d_ref(:,ch_corr);
    d_fpa = FPA(time, signal, ref,configuration);
    di = di + 1;
    d_corr(di) = d_fpa;
    d_str{di} = ['RE-',num2str(laser)];
end;

% vHPC data processing
ch = pc_d.vHPC_ch;
laser0 = laser;
laser = pc_d.vHPC_laser;
if ch > 0
    if laser == 470
        fn = pc_d.f_470;
    elseif laser == 580
        fn = pc_d.f_580;
    elseif laser == 405
        fn = pc_d.f_405;
    end;
    ch_corr = ch + ch_delta;
    if laser ~= laser0
        d = xlsread(fn);
    end;
    signal = d(:,ch_corr);
    time = [1:size(signal,1)]/photo_fre;
    time = time';    
    ref =d_ref(:,ch_corr);
    d_fpa = FPA(time, signal, ref,configuration);
    di = di + 1;
    d_corr(di) = d_fpa;
    d_str{di} = ['vHPC-',num2str(laser)];
end;
