function [res_beh, res_beh_avg, event_period, single_beh, beh_avg] = fProcessing_response2beh_reverse(dff, ... 
                                                    d_beh, ...
                                                    photo_fre, ...
                                                    beh_event, ...
                                                    beh_fre, ...
                                                    t_offset_beh, ...
                                                    beh_time_thre, ...
                                                    beh_avg_pre, ...
                                                    beh_avg_post, ...
                                                    beh_t0, ...
                                                    beh_t1, ...
                                                    force_len, ...
                                                    fig_flag)

i0 = find(beh_event(:,1) >= beh_t0(1),1);
i1 = size(find(beh_event(:,2) <= beh_t1(end)),1);
l_event_all = beh_event(i0:i1,2)-beh_event(i0:i1,1);
l_event0 = max(beh_event(i0:i1,2)-beh_event(i0:i1,1));
l_sec = beh_avg_pre+l_event0+beh_avg_post;
beh_event0 = beh_event(i0:i1,:);
if force_len <=0
    l_photo = ceil(l_sec * photo_fre);
    l_beh = ceil(l_sec * beh_fre);
else
    l_photo = force_len;
    l_beh = force_len / photo_fre * beh_fre;    
end;
n_dff = size(dff,1);
n_d_beh = size(d_beh,1);
res_beh0 = zeros(i1-i0+1,l_photo);
res_beh = zeros(i1-i0+1,l_photo);
event_period = zeros(i1-i0+1,2);
n_rb = 0;

for i = i0:i1
    tm = beh_event(i,2);
    xm = round(tm * photo_fre);  
    x0 = xm - beh_avg_pre * photo_fre;
    x0_i = 1;
    x1 = x0 + l_photo - 1;
    x1_i = l_photo;    
    if x0 < 1
        x0_i = x0_i + (1-x0);
        x0 = 1;
    end;
    if x1 > n_dff
        x1_i = x1_i - (x1-n_dff);
        x1 = n_dff;
    end;  
    n_rb = n_rb + 1;
    res_beh0(n_rb,x0_i:x1_i) = dff(x0:x1);

    tm = beh_event(i,2)-t_offset_beh;
    xm = round(tm * beh_fre);  
    x0 = xm - beh_avg_pre * beh_fre;
    x0_i = 1;
    x1 = x0 + l_beh - 1;
    x1_i = l_beh;    
    if x0 < 1
        x0_i = x0_i + (1-x0);
        x0 = 1;
    end;
    if x1 > n_d_beh
        x1_i = x1_i - (x1-n_d_beh);
        x1 = n_d_beh;
    end;     
    single_beh0(n_rb,x0_i:x1_i) = d_beh(x0:x1);   
end;

[l_all_sort,i_sort] = sort(l_event_all,'descend');
ii = 0;
test_p = size(beh_t0,2);
idx = -1;
for i = 1:n_rb
    t0 = beh_event0(i_sort(i),1);
    flag0 = false;
    for i0 = 1:test_p
        if t0 >= beh_t0(i0)
            if t0 < beh_t1(i0)
                flag0 = true;
            end;
        end;
    end;
    if flag0 == true
        ii=ii+1;  
        res_beh(ii,:) = res_beh0(i_sort(i),:);
        event_period(ii,:) = beh_event0(i_sort(i),:);
        single_beh(ii,:) = single_beh0(i_sort(i),:);
        if beh_event0(i_sort(i),2) - t0 >= beh_time_thre
            idx = ii;
        end;
    end;
end;


res_beh = res_beh(1:ii,:);
event_period = event_period(1:ii,:);
single_beh = single_beh(1:ii,:);

if idx == -1 
    res_beh_avg = 0;
    beh_avg = 0;
else
    res_beh_avg = mean(res_beh(1:idx,:));
    beh_avg = mean(single_beh(1:idx,:));
    if fig_flag == true
        figure
        subplot(3,1,1);
        imagesc(single_beh(1:idx,:));
        subplot(3,1,2);
        imagesc(res_beh(1:idx,:));
        subplot(3,1,3);
        hold on
        plot([1:l_photo]/photo_fre,res_beh_avg);
        plot([1:l_beh]/beh_fre,beh_avg); 
        hold off
        y0 = min([res_beh_avg,beh_avg]);
        y1 = max([res_beh_avg,beh_avg]);
        axis([0,l_photo/photo_fre,y0,y1]);
    end;
end;