function s_ratio = fState_ratio(state_t, time_threshold, total_time)

df_state_t = state_t(:,2)-state_t(:,1);
count_i = find(df_state_t >= time_threshold);
state_count = df_state_t(count_i);
s_ratio = sum(state_count)/total_time;