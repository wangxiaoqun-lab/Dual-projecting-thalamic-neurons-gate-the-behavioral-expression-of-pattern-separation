function [start_i, end_i] = fTime_periods_reconstruction(goal_s)

beh_len = size(goal_s,1);
diff_goal_s = diff(goal_s);
start_i = find(diff_goal_s==1)'+1;
if goal_s(1) == 1 start_i= [1 start_i]; end;
end_i = find(diff_goal_s==-1)';
if goal_s(end) == 1 end_i= [end_i beh_len]; end;