function s_out = fTrace_fitting_modified(s0, xx, xmax, f) 

[sy,sx] = size(s0);
for i = 1:sy
    t0 = s0(i,:);
    p = polyfit(xx,t0(xx),f);
    tf = polyval(p,[1:xmax]);
    t1 = t0-tf;
    s1(i,:) = t1;
end;
s_out = s1;
