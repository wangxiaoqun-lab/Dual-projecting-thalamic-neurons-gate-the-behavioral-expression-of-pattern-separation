clear;
tic
% Usage declaration
Str_marker0 = 'FREEZING';
Col_marker0 = [0.9,0.9,1];
Str_marker1 = 'LOW STATE';
Col_marker1 = [0.9,1,0.9];
Str_marker2 = 'HIGH STATE';
Col_marker2 = [1,0,0];
photo_fre = 40;                                         
event_fre = 120;                                       
beh_fre = 50;                                           
shock_identify_fre = 50;
ds_shock = [178,238,298,358,418];                       % @ seconds
stim_duration = 450;                                    
sta_len = photo_fre*stim_duration;
states = zeros(sta_len,1);
states_shock = zeros(shock_identify_fre*stim_duration,1);
fold_fre = shock_identify_fre/photo_fre;
mark_x0 = 1700;                                         
mark_x1 = 2000;                                         
behaviour_x0 = 170;                                     
avg_pre_sec = 2;
avg_pre = 2*photo_fre;                      
avg_post_sec = 10;
avg_post = 10*photo_fre;
avg_length_sec = avg_pre_sec + avg_post_sec;
avg_length = avg_pre+avg_post;
avg = zeros(avg_length,9);
event_res_all = zeros(5000,800);
evntt_len_all = zeros(5000,1);
event_i0 = 0;
event_i1 = 0;
ch_delta = 1;                                           
beh_time_thre = 1;                                      
beh_avg_pre = 20;                                      
beh_avg_post = 2;                                    
beh_force = 80;

event_search_interval = 3;                              
ds_signal_start_i = 2;
ds_beh_start_i = 1;

Nphr_flag = false;                                     
Nphr_off = true;

st_l_sec = beh_force;
st_res = zeros(2000,st_l_sec*photo_fre);
st_beh = zeros(2000,st_l_sec*beh_fre);
st_period = zeros(2000,2);
st_code = zeros(2000,1);
st_i0 = 0;
st_i1 = 0;
fout_st = 'AutoOutput_single_target_res2beh_BLM_Recall.xlsx';
fout_st_mat = 'AutoOutput_single_target_res2beh_BLM_Recall.mat';

target_raw = zeros(avg_length_sec*photo_fre,500);
target_raw_n = 0;
target_raw_sample = zeros(1,500);
target_raw_avg = zeros(avg_length_sec*photo_fre,500);
target_raw_avg_n = 0;
target_raw_avg_sample = zeros(1,500);

z_pre_sec = 20;
z_post_sec = 60;
z_repeat_n = 10000;
z_rand_flag = -1;
z_time_mark = 1;
dp_Nphr_TrOFF_G35_A = [502 503 504];
dp_Nphr_TrOFF_G35_B = [505 506 507];

% void main()
run('H:\!! RE\!! photometry\FPA-master\setup.m');
fn = 'Input_Comments_multisite_Recall.xlsx';

pc_pool = dp_Nphr_TrOFF_G35_B 
ffn = 'dp_Nphr_TrOFF_G35_B_20241217.xlsx';
fn_4stages = 'dp_Nphr_TrOFF_G35_B_4stages_20241217.xlsx';

just_draw_flag = false;
Avg_normalized_flag = false;
fout00_h = '_sAMR_4ML_TrOFF_G35_B_ON_';
total_length = 720;

Nphr_flag = true;
Nphr_off = false;
state_flag = 1;                             % 1...freezing_t, 2...low_t
str_choosen_flag = 1;                       % 1...mPFC, 2...RE, 3...vHPC
reverse_flag = 0;                           % 0...event edge of start, 1...event edge of end
z_filter_flag = 0;
baseline_smooth = 20 * photo_fre;           % >0, dff = dff - smooth(dff,baseline_smooth);

present_tag = '';
if state_flag == 1
    present_tag = [present_tag, 'freezing '];
elseif state_flag == 2
    present_tag = [present_tag, 'low state '];
end;
if str_choosen_flag == 1
    target_str = 'mPFC';
    st_target_str = 'mPFC';
    present_tag = [present_tag, 'mPFC '];
elseif str_choosen_flag == 2
    target_str = 'RE';
    st_target_str = 'RE';
    present_tag = [present_tag, 'RE '];
elseif str_choosen_flag == 3
    target_str = 'vHPC';
    st_target_str = 'vHPC';
    present_tag = [present_tag, 'vHPC '];
end;
if reverse_flag == 0
    present_tag = [present_tag, 'start '];
elseif reverse_flag == 1
    present_tag = [present_tag, 'end '];
    z_pre_sec = 60;
    z_post_sec = 20;
    z_time_mark = 2;
end;
present_tag


[d0,t0,r0] = xlsread(fn); 
i = 1;
flag0 = true;
n_r0 = size(r0,1);
while flag0 == true
    if isnan(r0{i,1}) flag0 = false; end;
    i=i+1;
    if i > n_r0 flag0 = false; end;
end;
i=i-1;
[pc_d,pc_n] = fProcess_behaviour_raw_recall(r0(1:i,:));
pc_no = [];
for i = 1:pc_n
    pc_no(i) = pc_d(i).no;
end;

count_cell_num = 0;
num_pc_pool = size(pc_pool,2);
res_4stage = zeros(num_pc_pool,6);
r4n = 0;
for i = pc_pool
    f1 = find(pc_no==i);
    if (i == 371) 
        event_search_interval = 1;
    end;
    if (i == 368) 
        event_search_interval = 0.5;
    end;
    
    if isempty(f1) == 0
        count_cell_num = count_cell_num + 1;
        [d_corr,d_str] = fProcessing_rawdata_FPA(pc_d(f1),photo_fre,ch_delta);
        nch_d_corr = size(d_corr,2);
        
        d_event = fProcessing_event(pc_d(f1));
        
        fn_d_event_all = pc_d(f1).f_event;
        d_event_all = xlsread(fn_d_event_all);

        ds = fFind_event_starting(d_event, event_fre, 0.1, 0, event_fre*event_search_interval);
        ds_signal = ceil(ds * photo_fre / event_fre);
        
        d_beh = fProcessing_behaviour(pc_d(f1).f_learning,beh_fre);
        ds_beh = fFind_event_starting(d_beh, beh_fre, 0.1, 0, beh_fre*event_search_interval);
        ds_signal_start_i = pc_d(f1).photometry_start_marker;   
        ds_beh_start_i = pc_d(f1).fearbox_start_marker;
        t_offset_beh = ds_signal(ds_signal_start_i)/photo_fre - ds_beh(ds_beh_start_i)/beh_fre;
        if (i == 283) || (i == 288)
            t_offset_beh = 42;
        end;
        
        if Nphr_flag == true
            d_Nphr_event = fProcessing_Nphr_event(pc_d(f1));
            ds_Nphr = fFind_event_starting(d_Nphr_event, event_fre, 0.1, 0, event_fre*190);
            t00 = 0;
            t00_4beh = t_offset_beh;
            t01 = round(ds_Nphr(1) / event_fre);
            t02 = t01 + 180;
            t03 = round(ds_Nphr(2) / event_fre);
            t04 = min([720,t03+180]);      
            t04_4beh = min([720+t_offset_beh, t03+180]);
            ds_Nphr_time = [t00, t01, t02, t03, t04];
            ds_Nphr_time_4beh = [t00_4beh, t01, t02, t03, t04_4beh];            
            f00 = ds_Nphr_time.*photo_fre;
            f00(6) = size(d_corr(1).dff,1);
            beh_ratio_stage = round((ds_Nphr_time_4beh - t_offset_beh) * beh_fre);
            r4n = r4n + 1; 
            res_4stage(r4n,:) = [f1, round((ds_Nphr_time_4beh - t_offset_beh) * photo_fre)];          
        else
            beh_ratio_stage = [0 180 360 540 720] * beh_fre;   
            r4n = r4n + 1;
            res_4stage(r4n,:) = [f1, [0 180 360 540 720] * photo_fre];
        end;
       
        
        fBSS_state = -1;                            
        fBSS_thre = 1*beh_fre;                      
        fBSS_d_beh = d_beh;                         
        fBSS_beh_ratio_stage = beh_ratio_stage;    
        beh_stat = fBehavior_state_statistics(fBSS_state, fBSS_thre, fBSS_d_beh, fBSS_beh_ratio_stage);
        fs_i0 = count_cell_num;
        fs_i1 = fs_i0 + num_pc_pool;
        freezing_set_id(fs_i0) = i;
        freezing_set_id(fs_i1) = i;
        freezing_set_name{fs_i0} = pc_d(i).name;
        freezing_set_name{fs_i1} = pc_d(i).name;
        freezing_set(fs_i0,:) = beh_stat(1,:); 
        freezing_set(fs_i1,:) = beh_stat(2,:);
       
        
        freezing_t = fFind_behaviour_states(d_beh, beh_fre, -1);
        freezing_t = freezing_t + t_offset_beh;
        freezing_ratio = fState_ratio(freezing_t, 1, 720);
        low_t = fFind_behaviour_states(d_beh, beh_fre, 0);
        low_t = low_t + t_offset_beh; 
        low_ratio = fState_ratio(low_t, 1, 720);
        high_t = fFind_behaviour_states(d_beh, beh_fre, 1);
        high_t = high_t + t_offset_beh; 
        fprintf('Name ... %s \nFreezing ... %f \nLow State ...%f \n',pc_d(f1).name, freezing_ratio, low_ratio);
        
        for j = 1:nch_d_corr
            if baseline_smooth > 0 
                if Nphr_flag == false
                    d_corr(j).dff = d_corr(j).dff - smooth(d_corr(j).dff, baseline_smooth);
                elseif Nphr_flag == true
                    dff0 = d_corr(j).dff;
                    for jj = 1:5
                        xx00 = f00(jj) + 1;
                        xx01 = f00(jj+1);
                        dff0(xx00:xx01) = dff0(xx00:xx01) - smooth(dff0(xx00:xx01), baseline_smooth);
                    end;
                    d_corr(j).dff = dff0;
                end;
            end;
            [avg_raw, avg0] = fProcessing_average(d_corr(j).dff, ds_signal, photo_fre, avg_pre_sec, avg_post_sec);
            avg_res(j,:) = avg0;
            if strfind(d_str{j}, target_str) > 0 
                n_temp = size(avg_raw,2);
                n0 = target_raw_n + 1;
                n1 = target_raw_n + n_temp;
                target_raw(:,n0:n1) = avg_raw;
                target_raw_sample(n0:n1) = f1;
                target_raw_n = n1;
                
                target_raw_avg_n = target_raw_avg_n + 1;
                target_raw_avg(:,target_raw_avg_n) = avg0;
                target_raw_avg_sample(target_raw_avg_n) = f1;
            end;     
            
        end;
        
        [avg_raw, avg_event] = fProcessing_average(d_event, ds, event_fre, avg_pre_sec, avg_post_sec);
            

        
        for j = 1:nch_d_corr
            time_j0(1) = 0 + t_offset_beh;
            time_j1(1) = 720 + t_offset_beh;
            if Nphr_flag == true
                if Nphr_off == true
                    time_j0 = [ds_Nphr_time(1)+ t_offset_beh,ds_Nphr_time(3)];
                    time_j1 = [ds_Nphr_time(2),ds_Nphr_time(4)];
                else
                    time_j0 = [ds_Nphr_time(2),ds_Nphr_time(4)];
                    time_j1 = [ds_Nphr_time(3),ds_Nphr_time(5)+ t_offset_beh];
                end;
            end;

            beh_t0 = time_j0; 
            beh_t1 = time_j1;
            if state_flag == 1
                target_state_t = freezing_t;
            elseif state_flag ==2
                target_state_t = low_t;
            end;
            if reverse_flag == 0
                [res_beh, res_beh_avg, event_period, single_beh, beh_avg] = fProcessing_response2beh(d_corr(j).dff, ... 
                                                    d_beh, ...
                                                    photo_fre, ...
                                                    target_state_t, ...
                                                    beh_fre, ...
                                                    t_offset_beh, ...
                                                    beh_time_thre, ...
                                                    beh_avg_pre, ...
                                                    beh_avg_post, ...
                                                    beh_t0, ...
                                                    beh_t1, ...
                                                    beh_force*photo_fre);
            elseif reverse_flag == 1
                beh_avg_pre = 60;
                [res_beh, res_beh_avg, event_period, single_beh, beh_avg] = fProcessing_response2beh_reverse(d_corr(j).dff, ... 
                                                        d_beh, ...
                                                        photo_fre, ...
                                                        target_state_t, ...
                                                        beh_fre, ...
                                                        t_offset_beh, ...
                                                        beh_time_thre, ...
                                                        beh_avg_pre, ...
                                                        beh_avg_post, ...
                                                        beh_t0, ...
                                                        beh_t1, ...
                                                        beh_force*photo_fre);
            end;      
            
            if just_draw_flag == false
                 if strfind(d_str{j}, st_target_str) > 0 
                     avg0 = avg_res(j,:);
                     st_base0 = mean(avg0(1:photo_fre*avg_pre_sec));
                     st_h0 = max(avg0)-st_base0;

                     st_i0 = st_i1 + 1;
                     st_i1 = st_i1 + size(event_period,1);
                     if Avg_normalized_flag == true
                        st_res(st_i0:st_i1,:) = (res_beh-st_base0)/st_h0;
                     else
                         ci0_temp = round(t_offset_beh*40);
                         ci1_temp = ci0_temp + 720*40 - 1;
                         dd0_temp0 = d_corr(j).dff;
                         dd0_temp1 = dd0_temp0(ci0_temp:ci1_temp);
                         mm0_temp = mean(dd0_temp1);
                         sd0_temp = std(dd0_temp1);
                         st_res(st_i0:st_i1,:) = (res_beh-mm0_temp)/sd0_temp;
                     end;
                     st_beh(st_i0:st_i1,:) = single_beh;
                     st_period(st_i0:st_i1,:) = event_period;
                     st_code(st_i0:st_i1,:) = f1;
                 end;
            end;
        end;
        
        
        flag0 = fPlot_rawdata([pc_d(f1).name,'-NO-',num2str(f1)], ...
            d_corr, ...
            d_str, ...
            41, ...
            size(d_corr(1).dff,1), ...
            photo_fre, ...
            avg_pre_sec, ...
            avg_post_sec, ...
            avg_res, ...
            d_event, ...
            avg_event, ...
            event_fre, ...
            d_beh, ...
            beh_fre, ...
            freezing_t, ...
            low_t, ...
            high_t, ...
            t_offset_beh, ...
            ds_shock);
        

        fout00 = [fout00_h,num2str(i),'.xlsx'];
        data00 = fData_normalized_using_zscore(...
            fout00,...
            d_corr,...
            event_period,...
            photo_fre,...
            t_offset_beh,...
            total_length);
    end;
end;


    freezing_set_id = freezing_set_id';
    freezing_set_name = freezing_set_name';
    line1 = 'Freezing >= 1s';
    xlswrite(ffn,{line1},1,'C1');
    xlswrite(ffn,{'Total Time'},1,'C2');
    xlswrite(ffn,{'Ratio'},1,'G2');
    xlswrite(ffn,{'Number of events'},1,'K2');
    xlswrite(ffn,{'Mean time per events'},1,'O2');
    xlswrite(ffn,{'Std of time per events'},1,'S2');
    line3 = {'off-1','on-1','off-2','on-2'};
    xlswrite(ffn,line3,1,'C3');
    xlswrite(ffn,line3,1,'G3');
    xlswrite(ffn,line3,1,'K3');
    xlswrite(ffn,line3,1,'O3');
    xlswrite(ffn,line3,1,'S3');
    xlswrite(ffn,freezing_set_id(1:num_pc_pool),1,'A4');
    xlswrite(ffn,freezing_set_name(1:num_pc_pool),1,'B4');
    xlswrite(ffn,freezing_set(1:num_pc_pool,:),1,'C4');
    
    line1_1 = 'Freezing < 1s';
    xlswrite(ffn,{line1_1},1,['C',num2str(5+num_pc_pool)]);
    xlswrite(ffn,{'Total Time'},1,['C',num2str(6+num_pc_pool)]);
    xlswrite(ffn,{'Ratio'},1,['G',num2str(6+num_pc_pool)]);
    xlswrite(ffn,{'Number of events'},1,['K',num2str(6+num_pc_pool)]);
    xlswrite(ffn,{'Mean time per events'},1,['O',num2str(6+num_pc_pool)]);
    xlswrite(ffn,{'Std of time per events'},1,['S',num2str(6+num_pc_pool)]);
    line3 = {'off-1','on-1','off-2','on-2'};
    xlswrite(ffn,line3,1,['C',num2str(7+num_pc_pool)]);
    xlswrite(ffn,line3,1,['G',num2str(7+num_pc_pool)]);
    xlswrite(ffn,line3,1,['K',num2str(7+num_pc_pool)]);
    xlswrite(ffn,line3,1,['O',num2str(7+num_pc_pool)]);
    xlswrite(ffn,line3,1,['S',num2str(7+num_pc_pool)]);
    xlswrite(ffn,freezing_set_id(num_pc_pool+1:end),1,['A',num2str(8+num_pc_pool)]);
    xlswrite(ffn,freezing_set_name(num_pc_pool+1:end),1,['B',num2str(8+num_pc_pool)]);
    xlswrite(ffn,freezing_set(num_pc_pool+1:end,:),1,['C',num2str(8+num_pc_pool)]);

dataout = [st_code(1:st_i1,:),st_period(1:st_i1,:),st_res(1:st_i1,:),st_beh(1:st_i1,:)];

save(fout_st_mat,'dataout');

xlswrite(fn_4stages, res_4stage);

toc










