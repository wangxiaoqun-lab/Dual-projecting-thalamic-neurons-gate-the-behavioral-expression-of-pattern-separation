function beh = fAssign_Behavior_Markers_StayE_4E(out_f,out_m,dl)
freq  = 40;
freezing_thre = 1*freq;  
d5s = zeros(dl,1);                      
ml = size(out_m,1);

fl = size(out_f,1);
for i = 1:fl
    if out_f(i,3) < freezing_thre
        d5s(out_f(i,1)) = 1;            % =1, stay start, stay = 不足 thre 的停顿
        if out_f(i,2) < 28800
            d5s(out_f(i,2)+1) = 2;          % =1, stay end, stay = 不足 thre 的停顿, 实际上是moving的第1帧
        end;
    else
        d5s(out_f(i,1)) = 3;            % =3, freezing start
        if out_f(i,2) < 28800
            d5s(out_f(i,2)+1) = 4;          % =4, freezing end
        end;
    end;
end;
beh = d5s;
