function [out_f,out_m] = fBehavior_Dissect_StayE(d_beh)

trace_l = 720*40;

out_f = round(d_beh);
n = size(out_f,1);
out_m = [];
mn = 0;

if out_f(1,1) >1
    mn = mn+1;
    out_m(mn,1) = 1;
    out_m(mn,2) = out_f(1,1)- 1;
end;

for i = 1:n-1
    i0 = out_f(i,2)+1;
    i1 = out_f(i+1,1)-1;
    if i1>=i0 
        mn = mn + 1;
        out_m(mn,1) = i0;
        out_m(mn,2) = i1;
    end;
end;

if out_f(n,2) < trace_l
    mn = mn + 1;
    out_m(mn,1) = out_f(n,2)+1;
    out_m(mn,2) = trace_l;
end;

out_f(:,3) = out_f(:,2) - out_f(:,1) + 1;
out_m(:,3) = out_m(:,2) - out_m(:,1) + 1;

    
    
    

