function [rsq,rsq_adj] = fCalculate_Rs(x,y,p,S);

yfit = polyval(p,x);
yresid = y-yfit;
SSresid = sum(yresid.^2);
SStotal = (length(y)-1) * var(y);
rsq = 1 - SSresid/SStotal
rsq_adj = 1 - SSresid/SStotal * (length(y)-1)/(length(y)-length(p))
