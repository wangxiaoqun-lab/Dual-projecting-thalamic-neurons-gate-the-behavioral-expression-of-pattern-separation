function [i_freezing, i_stay, i_moving] = fIdx_of_behaviour(out_f,out_m,f_thre)

i_freezing = [];
i_stay = [];
i_moving = [];

ii_f = find(out_f(:,3)>=f_thre);
ii_fn = length(ii_f);
for i = 1:ii_fn
    i0 = ii_f(i);
    i_freezing = [i_freezing, [out_f(i0,1):out_f(i0,2)]];
end;

ii_s = find(out_f(:,3)<f_thre);
ii_sn = length(ii_s);
for i = 1:ii_sn
    i0 = ii_s(i);
    i_stay = [i_stay, [out_f(i0,1):out_f(i0,2)]];
end;

ii_mn = size(out_m,1);
for i = 1:ii_mn
    i_moving = [i_moving, [out_m(i,1):out_m(i,2)]];
end;
