function [mPFC_ks, mPFC_preds, vHPC_ks, vHPC_preds, fnn, Freezing_ratio, R2s] = fKernal_Predict_v2_StayE_4ER2(path_in, numBehaviors, preWindow, postWindow, plot_flag)

freq = 40;
thre = 1*freq;
def_fdr = '_Beh\'

fns = dir([path_in,'_*.xlsx']);
fnn = size(fns,1);

beh_fdr = [def_fdr,path_in(1:end-1),'_Beh\'];
fns_beh = dir([beh_fdr,'_*.xlsx']);
fns_beh_n = size(fns_beh,1);

mPFC_ks = [];
mPFC_preds = [];
vHPC_ks = [];
vHPC_preds = [];
Freezing_ratio = zeros(fnn,1);
R2s = zeros(fnn,8);                         

for i = 1:fnn    
    fn = fns(i).name;
    d = xlsread([path_in,fn]);

    fn_beh = fns_beh(i).name;
    d_beh = xlsread([beh_fdr,fn_beh]);
    
    [out_f,out_m] = fBehavior_Dissect_StayE(d_beh);
    [i_freezing, i_stay, i_moving] = fIdx_of_behaviour(out_f,out_m,thre);

    fii = find(out_f(:,3)>=thre);
    Freezing_ratio(i)=sum(out_f(fii,3))/size(d,1);

    beh = fAssign_Behavior_Markers_StayE_4E(out_f,out_m, size(d,1));

    res = d(:,1);                                   % =1, mPFC calcium res
    [mPFC_k, mPFC_pred] = fRidge_Reg(beh, res, numBehaviors, preWindow, postWindow, plot_flag);
    R2s(i,1) = fR2_calculation(res, mPFC_pred);
    R2s(i,2) = fR2_calculation(res(i_freezing), mPFC_pred(i_freezing));
    R2s(i,3) = fR2_calculation(res(i_stay), mPFC_pred(i_stay));
    R2s(i,4) = fR2_calculation(res(i_moving), mPFC_pred(i_moving));

    res = d(:,3);                                   % =3, vHPC calcium res
    [vHPC_k, vHPC_pred] = fRidge_Reg(beh, res, numBehaviors, preWindow, postWindow, plot_flag);
    R2s(i,5) = fR2_calculation(res, vHPC_pred);
    R2s(i,6) = fR2_calculation(res(i_freezing), vHPC_pred(i_freezing));
    R2s(i,7) = fR2_calculation(res(i_stay), vHPC_pred(i_stay));
    R2s(i,8) = fR2_calculation(res(i_moving), vHPC_pred(i_moving));

    mPFC_ks = cat(1, mPFC_ks, mPFC_k);
    mPFC_preds = cat(1, mPFC_preds, mPFC_pred);
    vHPC_ks = cat(1, vHPC_ks, vHPC_k);
    vHPC_preds = cat(1, vHPC_preds, vHPC_pred);
end;    