function [avg0,sd0,se0,xx,yy] = fPatch_parameters(ss,preWindow,postWindow)

avg0 = mean(ss);
sd0 = std(ss);
n0 = size(ss,1);
se0 = sd0/sqrt(n0);
avg0_up = avg0+se0;
avg0_down = avg0-se0;
x0 = [1:preWindow+1+postWindow];
xx = [x0,x0(end:-1:1)];
yy = [avg0_up,avg0_down(end:-1:1)];
    