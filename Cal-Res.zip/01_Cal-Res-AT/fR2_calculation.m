function R2 = fR2_calculation(res, pred)

SS_res = sum((res-pred).^2);
SS_tot = sum((res-mean(res)).^2);
R2 = 1-SS_res/SS_tot;
