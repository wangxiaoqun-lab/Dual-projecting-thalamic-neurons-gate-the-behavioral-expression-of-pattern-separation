function [avg0, sd0, se0] = fSTA_trace(trace0)

[n,length0] = size(trace0);
avg0 = zeros(1,length0);
sd0 = zeros(1,length0);
se0 = zeros(1,length0);

for i = 1:length0
    ii = find(isnan(trace0(:,i))==0);
    temp = trace0(ii,i);
    avg0(i) = mean(temp);
    sd0(i) = std(temp);
    se0(i) = sd0(i)/sqrt(length(ii));
end;