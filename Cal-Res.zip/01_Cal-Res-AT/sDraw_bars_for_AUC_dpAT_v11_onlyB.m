ww = [200:280];
figure('Position',[100,100,800,800])
myColor = [1 1 1 1 2 2 2 2];
myAlpha = [1 0.5 1 0.5 1 0.5 1 0.5];
bx = [1 2 3 4 5 6 7 8];
MS = 160;
hh = [0 0 0 0];
pp = [0 0 0 0];
for i = 3
     % mPFC A 
    hold on
    ii = [i:numBehaviors:fnn_ca*numBehaviors];
    mpfc_a1 = mean(mPFC_ks_ca(ii,ww)')';  
    ii = [i:numBehaviors:fnn_ga*numBehaviors];
    mpfc_a2 = mean(mPFC_ks_ga(ii,ww)')';
    [hh(1),pp(1)] = ttest2(mpfc_a1,mpfc_a2);
    
    
    % mPFC B
    ii = [i:numBehaviors:fnn_cb*numBehaviors];
    mpfc_b1 = mean(mPFC_ks_cb(ii,ww)')';
    ii = [i:numBehaviors:fnn_gb*numBehaviors];
    mpfc_b2 = mean(mPFC_ks_gb(ii,ww)')';  
    [hh(3),pp(3)] = ttest2(mpfc_b1,mpfc_b2);
    
    
    % vHPC A
    ii = [i:numBehaviors:fnn_ca*numBehaviors];
    vhpc_a1 = mean(vHPC_ks_ca(ii,ww)')';   
    ii = [i:numBehaviors:fnn_ga*numBehaviors];
    vhpc_a2 = mean(vHPC_ks_ga(ii,ww)')';
    [hh(2),pp(2)] = ttest2(vhpc_a1,vhpc_a2);
    

    % vHPC B
    ii = [i:numBehaviors:fnn_cb*numBehaviors];
    vhpc_b1 = mean(vHPC_ks_cb(ii,ww)')';
    ii = [i:numBehaviors:fnn_gb*numBehaviors];
    vhpc_b2 = mean(vHPC_ks_gb(ii,ww)')';
    [hh(4),pp(4)] = ttest2(vhpc_b1,vhpc_b2);
    
    
    subplot(2,2,i);
    hold on
    
    auc_avg(1) = mean(mpfc_a1);
    auc_avg(2) = mean(mpfc_a2);
    auc_avg(3) = mean(vhpc_a1);
    auc_avg(4) = mean(vhpc_a2);
    auc_avg(5) = mean(mpfc_b1);
    auc_avg(6) = mean(mpfc_b2);
    auc_avg(7) = mean(vhpc_b1);
    auc_avg(8) = mean(vhpc_b2);
    
    auc_se(1) = std(mpfc_a1)/sqrt(fnn_ca);
    auc_se(2) = std(mpfc_a2)/sqrt(fnn_ga);
    auc_se(3) = std(mpfc_a1)/sqrt(fnn_ca);
    auc_se(4) = std(mpfc_a2)/sqrt(fnn_ga);
    auc_se(5) = std(vhpc_b1)/sqrt(fnn_cb);
    auc_se(6) = std(vhpc_b2)/sqrt(fnn_gb);
    auc_se(7) = std(vhpc_b1)/sqrt(fnn_cb);
    auc_se(8) = std(vhpc_b2)/sqrt(fnn_gb);
    
    
    for j = 1:8
        scatter(bx(j),auc_avg(j),MS,'MarkerFaceColor',c(myColor(j),:),'MarkerEdgeColor','none','MarkerFaceAlpha',myAlpha(j));
        if mod(j,2) == 0
            plot([bx(j-1),bx(j)], [auc_avg(j-1),auc_avg(j)], 'color', c(myColor(j),:));
            text(bx(j-1),0.45,num2str(pp(j/2)));
        end;
    end;
    

    e = errorbar(bx,auc_avg,auc_se,'LineStyle','none');
    e.CapSize = 0;
    e.Color = 'Black';
    hold off
    axis([4.5,8.5,-0.2,0.4]);
    
end