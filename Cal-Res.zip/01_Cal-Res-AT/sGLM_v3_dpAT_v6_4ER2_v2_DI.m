clear;
c = colormap("lines");
tic
numBehaviors = 4;      

preWindow = 200;        
postWindow = 200;       
plot_flag = false;
freq  = 40;
freezing_thre = 1*freq;                      

path_in = 'dpAT_C_A_DI\';
[mPFC_ks_ca, mPFC_preds_ca, vHPC_ks_ca, vHPC_preds_ca, fnn_ca, frr_ca,R2_ca] = fKernal_Predict_v2_StayE_4ER2(path_in, numBehaviors, preWindow, postWindow, plot_flag);
path_in = 'dpAT_C_B_DI\';
[mPFC_ks_cb, mPFC_preds_cb, vHPC_ks_cb, vHPC_preds_cb, fnn_cb, frr_cb,R2_ga] = fKernal_Predict_v2_StayE_4ER2(path_in, numBehaviors, preWindow, postWindow, plot_flag);
path_in = 'dpAT_G_A_v2_DI\';
[mPFC_ks_ga, mPFC_preds_ga, vHPC_ks_ga, vHPC_preds_ga, fnn_ga, frr_ga,R2_cb] = fKernal_Predict_v2_StayE_4ER2(path_in, numBehaviors, preWindow, postWindow, plot_flag);
path_in = 'dpAT_G_B_v2_DI\';
[mPFC_ks_gb, mPFC_preds_gb, vHPC_ks_gb, vHPC_preds_gb, fnn_gb, frr_gb,R2_gb] = fKernal_Predict_v2_StayE_4ER2(path_in, numBehaviors, preWindow, postWindow, plot_flag);

toc

%%
figure('Position',[50,50,1000,800])
for i = 1:numBehaviors
    
    % mPFC A 
    subplot(numBehaviors,4,i*4-3)
    hold on
    ii = [i:numBehaviors:fnn_ca*numBehaviors];
    plot(mean(mPFC_ks_ca(ii,:)),'LineWidth',1,'Color',c(1,:));
    [avg0,sd0,se0,xx,yy] = fPatch_parameters(mPFC_ks_ca(ii,:),preWindow,postWindow);
    patch(xx,yy,c(1,:),'EdgeColor','none','FaceAlpha',0.3);

    ii = [i:numBehaviors:fnn_ga*numBehaviors];
    plot(mean(mPFC_ks_ga(ii,:)),'Linewidth',2,'Color',c(1,:));
    [avg0,sd0,se0,xx,yy] = fPatch_parameters(mPFC_ks_ga(ii,:),preWindow,postWindow);
    patch(xx,yy,c(1,:),'EdgeColor','none','FaceAlpha',0.3);
    
    hold off
    if i == numBehaviors xlabel('Time relative to behavior onset (frames)'); end;
    ylabel('Ca response');
    title(['mPFC A' num2str(i) ' kernel']);
    xlim([0,preWindow+1+postWindow])


    % mPFC B
    subplot(numBehaviors,4,i*4-1)
    hold on    
    
    ii = [i:numBehaviors:fnn_cb*numBehaviors];
    plot(mean(mPFC_ks_cb(ii,:)),'Linewidth',1,'Color',c(2,:));
    [avg0,sd0,se0,xx,yy] = fPatch_parameters(mPFC_ks_cb(ii,:),preWindow,postWindow);
    patch(xx,yy,c(2,:),'EdgeColor','none','FaceAlpha',0.3);
    
    ii = [i:numBehaviors:fnn_gb*numBehaviors];
    plot(mean(mPFC_ks_gb(ii,:)),'Linewidth',2,'Color',c(2,:));
    [avg0,sd0,se0,xx,yy] = fPatch_parameters(mPFC_ks_gb(ii,:),preWindow,postWindow);
    patch(xx,yy,c(2,:),'EdgeColor','none','FaceAlpha',0.3);
    
    hold off
    if i == numBehaviors xlabel('Time relative to behavior onset (frames)'); end;
    ylabel('Ca response');
    title(['mPFC B' num2str(i) ' kernel']);
    xlim([0,preWindow+1+postWindow])

    

    % vHPC A
    subplot(numBehaviors,4,i*4-2)
    hold on
    ii = [i:numBehaviors:fnn_ca*numBehaviors];
    plot(mean(vHPC_ks_ca(ii,:)),'LineWidth',1,'Color',c(1,:));
    [avg0,sd0,se0,xx,yy] = fPatch_parameters(vHPC_ks_ca(ii,:),preWindow,postWindow);
    patch(xx,yy,c(1,:),'EdgeColor','none','FaceAlpha',0.3);

    ii = [i:numBehaviors:fnn_ga*numBehaviors];
    plot(mean(vHPC_ks_ga(ii,:)),'LineWidth',2,'Color',c(1,:));
    [avg0,sd0,se0,xx,yy] = fPatch_parameters(vHPC_ks_ga(ii,:),preWindow,postWindow);
    patch(xx,yy,c(1,:),'EdgeColor','none','FaceAlpha',0.3);
    
    hold off
    if i == numBehaviors xlabel('Time relative to behavior onset (frames)'); end;
    title(['vHPC A' num2str(i) ' kernel']);
    xlim([0,preWindow+1+postWindow])
    

    % vHPC B
    subplot(numBehaviors,4,i*4)
    hold on
    
    ii = [i:numBehaviors:fnn_cb*numBehaviors];
    plot(mean(vHPC_ks_cb(ii,:)),'LineWidth',1,'Color',c(2,:));
    [avg0,sd0,se0,xx,yy] = fPatch_parameters(vHPC_ks_cb(ii,:),preWindow,postWindow);
    patch(xx,yy,c(2,:),'EdgeColor','none','FaceAlpha',0.3);

    ii = [i:numBehaviors:fnn_gb*numBehaviors];
    plot(mean(vHPC_ks_gb(ii,:)),'LineWidth',2,'Color',c(2,:));
    [avg0,sd0,se0,xx,yy] = fPatch_parameters(vHPC_ks_gb(ii,:),preWindow,postWindow);
    patch(xx,yy,c(2,:),'EdgeColor','none','FaceAlpha',0.3);

    hold off
    if i == numBehaviors xlabel('Time relative to behavior onset (frames)'); end;
    title(['vHPC B' num2str(i) ' kernel']);
    xlim([0,preWindow+1+postWindow])
    
end

%% 
figure('Position',[100,100,800,800])
SM = 160;

% vHPC_B
mark_i = 3;
peak_i = 300;


ii0_cb = [mark_i:numBehaviors:fnn_cb*numBehaviors];
x0_cb = mean(vHPC_ks_cb(ii0_cb,200:280)')';

ii0_gb = [mark_i:numBehaviors:fnn_gb*numBehaviors];
x0_gb = mean(vHPC_ks_gb(ii0_gb,200:280)')';

x0 = [x0_cb', x0_gb'];
y0 = [frr_cb', frr_gb'];

xx = x0;
yy = y0;

x_fit = [-5,12];
[p,S,mu] = polyfit(xx,yy,1);
p = polyfit(xx,yy,1);
[y_fit, delta] = polyval(p,x_fit,S);
[rsq,rsq_adj] = fCalculate_Rs(xx,yy,p,S);

AB_color = c(2,:);
subplot(2,2,4)
hold on

scatter(x0_cb, frr_cb, SM, ...
         'MarkerFaceColor',AB_color,'MarkerEdgeColor','none');%,'MarkerFaceAlpha',0.7);
scatter(x0_gb, frr_gb, SM, ...
         'MarkerFaceColor',AB_color,'MarkerEdgeColor','none','MarkerFaceAlpha',0.5);




plot(x_fit,y_fit,'linewidth',1,'color',AB_color);
plot(x_fit,y_fit+2*delta,'linewidth',1,'color',AB_color);
plot(x_fit,y_fit-2*delta,'linewidth',1,'color',AB_color);
text(0,0.6,['R^2 = ',num2str(rsq)]);
text(0,0.5,['Adjusted R^2 = ',num2str(rsq_adj)]);
axis([-0.7,0.5,-0.1,1.1]);
hold off
title('vHPC Recall B');

%
% vHPC_A
mark_i = 3;
peak_i = 190;   

ii0_ca = [mark_i:numBehaviors:fnn_ca*numBehaviors];
x0_ca = mean(vHPC_ks_ca(ii0_ca,200:280)')';


ii0_ga = [mark_i:numBehaviors:fnn_ga*numBehaviors];
x0_ga = mean(vHPC_ks_ga(ii0_ga,200:280)')';


x0 = [x0_ca', x0_ga'];
y0 = [frr_ca', frr_ga'];

xx = x0;
yy = y0;

x_fit = [-5,12];
[p,S,mu] = polyfit(xx,yy,1);
p = polyfit(xx,yy,1);
[y_fit, delta] = polyval(p,x_fit,S);
[rsq,rsq_adj] = fCalculate_Rs(xx,yy,p,S);

AB_color = c(1,:);
subplot(2,2,2);
hold on

scatter(x0_ca, frr_ca, SM, ...
         'MarkerFaceColor',AB_color,'MarkerEdgeColor','none');
scatter(x0_gb, frr_ga, SM, ...
         'MarkerFaceColor',AB_color,'MarkerEdgeColor','none','MarkerFaceAlpha',0.5);


plot(x_fit,y_fit,'linewidth',1,'color',AB_color);
plot(x_fit,y_fit+2*delta,'linewidth',1,'color',AB_color);
plot(x_fit,y_fit-2*delta,'linewidth',1,'color',AB_color);
text(0,0.6,['R^2 = ',num2str(rsq)]);
text(0,0.5,['Adjusted R^2 = ',num2str(rsq_adj)]);
axis([-0.25,0.95,0.2,1.4]);
hold off
title('vHPC Recall A');






%
% mPFC_A
mark_i = 3;
peak_i = 190;

ii0_ca = [mark_i:numBehaviors:fnn_ca*numBehaviors];
x0_ca = mean(mPFC_ks_ca(ii0_ca,200:280)')';


ii0_ga = [mark_i:numBehaviors:fnn_ga*numBehaviors];
x0_ga = mean(mPFC_ks_ga(ii0_ga,200:280)')';


x0 = [x0_ca', x0_ga'];
y0 = [frr_ca', frr_ga'];
    
xx = x0;
yy = y0;

x_fit = [-5,12];
[p,S,mu] = polyfit(xx,yy,1);
p = polyfit(xx,yy,1);
[y_fit, delta] = polyval(p,x_fit,S);
[rsq,rsq_adj] = fCalculate_Rs(xx,yy,p,S);

AB_color = c(1,:);
subplot(2,2,1);
hold on

scatter(x0_ca, frr_ca, SM, ...
         'MarkerFaceColor',AB_color,'MarkerEdgeColor','none');%,'MarkerFaceAlpha',0.7);
scatter(x0_ga, frr_ga, SM, ...
         'MarkerFaceColor',AB_color,'MarkerEdgeColor','none','MarkerFaceAlpha',0.5);


plot(x_fit,y_fit,'linewidth',1,'color',AB_color);
plot(x_fit,y_fit+2*delta,'linewidth',1,'color',AB_color);
plot(x_fit,y_fit-2*delta,'linewidth',1,'color',AB_color);
text(0,0.6,['R^2 = ',num2str(rsq)]);
text(0,0.5,['Adjusted R^2 = ',num2str(rsq_adj)]);
axis([-0.1,1.1,0.2,1.4]);
hold off
    
title('mPFC Recall A');
    
%
% mPFC_B
mark_i = 3;
peak_i = 200;

ii0_cb = [mark_i:numBehaviors:fnn_cb*numBehaviors];
x0_cb = mean(mPFC_ks_cb(ii0_cb,200:280)')';

ii0_ga = [mark_i:numBehaviors:fnn_ga*numBehaviors];
x0_gb = mean(mPFC_ks_gb(ii0_gb,200:280)')';


x0 = [x0_cb', x0_gb'];
y0 = [frr_cb', frr_gb'];
    
xx = x0;
yy = y0;

x_fit = [-5,12];
[p,S,mu] = polyfit(xx,yy,1);
p = polyfit(xx,yy,1);
[y_fit, delta] = polyval(p,x_fit,S);
[rsq,rsq_adj] = fCalculate_Rs(xx,yy,p,S);

AB_color = c(2,:);
subplot(2,2,3)
hold on

scatter(x0_cb, frr_cb, SM, ...
         'MarkerFaceColor',AB_color,'MarkerEdgeColor','none');
scatter(x0_gb, frr_gb, SM, ...
         'MarkerFaceColor',AB_color,'MarkerEdgeColor','none','MarkerFaceAlpha',0.5);


plot(x_fit,y_fit,'linewidth',1,'color',AB_color);
plot(x_fit,y_fit+2*delta,'linewidth',1,'color',AB_color);
plot(x_fit,y_fit-2*delta,'linewidth',1,'color',AB_color);
text(-0.2,0.6,['R^2 = ',num2str(rsq)]);
text(-0.2,0.5,['Adjusted R^2 = ',num2str(rsq_adj)]);
axis([-0.3,0.9,-0.2,1]);
hold off
    
title('mPFC Recall B');