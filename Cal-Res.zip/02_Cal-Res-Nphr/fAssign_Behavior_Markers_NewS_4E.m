function beh = fAssign_Behavior_Markers_NewS_4E(out_f,out_m,dl,stages)

freq  = 40;
freezing_thre = 1*freq;  

d5s = zeros(dl,1);                       

ml = size(out_m,1);

fl = size(out_f,1);
for i = 1:fl
    if out_f(i,3) < freezing_thre
        d5s(out_f(i,1)) = 1;                % =1, stay start, stay = ���� thre ��ͣ��
        if out_f(i,2) < 28800
            d5s(out_f(i,2)+1) = 3;          % =3, stay end, stay = ���� thre ��ͣ��, ʵ������moving�ĵ�1֡
        end;        
    else
        d5s(out_f(i,1)) = 5;                % =5, freezing start
        if out_f(i,2) < 28800
            d5s(out_f(i,2)+1) = 7;          % =7, freezing end
        end;
    end;
end;

i0 = stages(2) + 1;
i1 = stages(3);
iit = find(d5s(i0:i1) > 0)+i0-1;
d5s(iit) = d5s(iit)+1;
i0 = stages(4) + 1;
i1 = stages(5);
iit = find(d5s(i0:i1) > 0)+i0-1;
d5s(iit) = d5s(iit)+1;

beh = d5s;
