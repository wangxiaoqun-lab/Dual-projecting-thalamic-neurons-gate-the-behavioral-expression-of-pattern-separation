function [i_off, i_on] = fBehavior_Dissect_onoff(i_beh, stages)

ii1 = find(i_beh<=stages(3));
window1 = i_beh(ii1);
wi1 = find(window1<=stages(2));
i_off = window1(wi1);
wi2 = find(window1>stages(2));
i_on = window1(wi2);

ii2 = find(i_beh>stages(3));
window2 = i_beh(ii2);
wi3 = find(window2<=stages(4));
i_off = [i_off, window2(wi3)];
wi4 = find(window2>stages(4));
i_on = [i_on, window2(wi4)];
