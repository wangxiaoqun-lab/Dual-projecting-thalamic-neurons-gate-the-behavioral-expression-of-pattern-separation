function [r0, r0_avg, du0, beh_i0, i_up, i_down, beh_flag0 ] = fGet_CalResToBeh_v2(d, ch_sig, ch_beh, beh_type, beh_thre, time0, time1, st0, flag_start_end)

xx = 401;
xr = 400;
xx0 = 1;
xx1 = 801;
freq = 40;
d_sig = d(:,ch_sig)';
d_beh = d(:,ch_beh)';
dl = length(d_sig);
pre = 1*freq;
post = 1*freq;

[out_f,out_m] = fBehavior_Dissect(d_beh);
fii0 = find(out_f(:,3) >= beh_thre);
out_f0 = out_f(fii0,:);
mii0 = find(out_m(:,3) >= beh_thre);
out_m0 = out_m(mii0,:);


if beh_type == 1
    i_start = out_f0(:,1);
    i_end = out_f0(:,2);
else
    if beh_type == 0
        i_start = out_m0(:,1);
        i_end = out_m0(:,2);
    else
        if beh_type == 2
            out_f00 = out_f;
            out_f00(1,4) = 1*freq;                              
            temp_l = size(out_f00,1);    
            temp_x = out_f00(1,2)+1;
            temp_i = find(out_m(:,1) == temp_x);
            out_f00(2:temp_l,4) = out_m(temp_i:temp_l-2+temp_i,3);
            out_f01 = out_f00(find(out_f00(:,3)>=beh_thre),:);
            out_f02 = out_f01(find(out_f01(:,4)>=10),:);        
            
            i_start = out_f02(:,1);
            i_end = out_f02(:,2);
        end;
    end;
end;
n_start = length(i_start); 
i_start0 = i_start;
iii0 = length(find(i_start < time0))+1;
iii1 = length(find(i_start<=time1));        
n_end = length(i_end);
i_end0 = i_end;
    
i_start = i_start0(iii0:iii1);
i_end = i_end0(iii0:iii1);
n_start0 = n_start;
n_start = length(i_start);

r0 = ones(n_start,xx1).*NaN;
r0_avg = zeros(1,xx1);
du0 = zeros(n_start, 2);
beh_i0 = [i_start',i_end'];
beh_flag0 = [];
for i = 1:n_start
    if flag_start_end == 1
        ii = i_start(i);
    else
        ii = i_end(i);
    end;
    
    ii0 = ii - xr;
    if ii0 >= 1
        tt0 = xx0;
    else
        tt0 = 2 - ii0;
        ii0 = 1;
    end;
    ii1 = ii + xr;
    if ii1 <= dl
        tt1 = xx1;
    else
        tt1 = 801 - (ii1-dl);
        ii1 = dl;
    end;
    
    r0(i,tt0:tt1) = d_sig(ii0:ii1);
    beh0(i,tt0:tt1) = d_beh(ii0:ii1);
    du0(i,1) = mean(r0(i,xx-pre:xx-1));
    du0(i,2) = mean(r0(i,xx:xx+post-1));
    beh_flag0(i) = length(find(st0<ii0));       %����Ϊ���ĸ�ʱ���
end;
for i = 1:xx1
    tt0 = find(isnan(r0(:,i)) == false);
    ttn = length(tt0);
    r0_avg(i) = sum(r0(tt0,i))/ttn;
end;
    
i_up = find((du0(:,1) - du0(:,2))<0);
i_down = find((du0(:,1) - du0(:,2))>=0);
beh_flag0 = beh_flag0';











