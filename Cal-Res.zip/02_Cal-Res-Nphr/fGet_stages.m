function [stages,sii] = fGet_stages(path_in, fn,AB_flag)

if AB_flag == 1
    d_fn = '_Stages\A_4stages.xlsx';
else
    if AB_flag == 2
        d_fn = '_Stages\B_4stages.xlsx';
    end;
end;

d = xlsread(d_fn);
temp = strfind(fn,'_');
ii = temp(end)+1;
id = str2num(fn(ii:end-5));

i = find(d(:,1) == id);
stages = d(i,2:end);

if isempty(strfind(path_in,'_off')) == false
    sii = [stages(1)+1,stages(2);stages(3)+1,stages(4)];
else
    if isempty(strfind(path_in,'_on')) == false
        sii = [stages(2)+1,stages(3);stages(4)+1,stages(5)];
    end;
end;

