function [mPFC_ks, mPFC_preds, mPFC_raws, vHPC_ks, vHPC_preds, vHPC_raws, fnn, Freezing_ratio, R2s] = fKernal_Predict_v6_NewS_4ER2(path_in, path_in2, numBehaviors, preWindow, postWindow, plot_flag, AB_flag)

freq = 40;
thre = 1*freq;
def_fdr = '_Beh\';

fns = dir([path_in,'_*.xlsx']);
fnn = size(fns,1);
fns2 = dir([path_in2,'_*.xlsx']);

beh_fdr = [def_fdr,path_in(1:end-1),'_Beh\'];
fns_beh = dir([beh_fdr,'_*.xlsx']);
fns_beh_n = size(fns_beh,1);
beh_fdr2 = [def_fdr,path_in2(1:end-1),'_Beh\'];
fns_beh2 = dir([beh_fdr2,'_*.xlsx']);

mPFC_ks = [];
mPFC_preds = [];
mPFC_raws = [];
vHPC_ks = [];
vHPC_preds = [];
vHPC_raws = [];
Freezing_ratio = zeros(fnn,2);
R2s = zeros(fnn,24);
i_all = [1:28800];
    
for i = 1:fnn    
    fn = fns(i).name;
    d = xlsread([path_in,fn]);

    fn_beh = fns_beh(i).name;
    d_beh = xlsread([beh_fdr,fn_beh]);
    fn_beh2 = fns_beh2(i).name;
    d_beh2 = xlsread([beh_fdr2,fn_beh2]);
    
    ds_beh = fMerge_beh(d_beh,d_beh2); 
    
    [out_f,out_m] = fBehavior_Dissect_StayE(ds_beh);
    [stages,sii] = fGet_stages(path_in, fn,AB_flag);
    
    beh = fAssign_Behavior_Markers_NewS_4E(out_f,out_m, size(d,1), stages);
    [i_freezing, i_stay, i_moving] = fIdx_of_behaviour(out_f,out_m,thre);
    [i_freezing_off, i_freezing_on] = fBehavior_Dissect_onoff(i_freezing, stages);
    [i_stay_off, i_stay_on] = fBehavior_Dissect_onoff(i_stay, stages);
    [i_moving_off, i_moving_on] = fBehavior_Dissect_onoff(i_moving, stages);
    [i_all_off, i_all_on] = fBehavior_Dissect_onoff(i_all, stages);

    res = d(:,1);                                   % =1, mPFC calcium res
    [mPFC_k, mPFC_pred] = fRidge_Reg(beh, res, numBehaviors, preWindow, postWindow, plot_flag);
    mPFC_raw = res;
    R2s(i,1) = fR2_calculation(res, mPFC_pred);
    R2s(i,2) = fR2_calculation(res(i_freezing), mPFC_pred(i_freezing));
    R2s(i,3) = fR2_calculation(res(i_stay), mPFC_pred(i_stay));
    R2s(i,4) = fR2_calculation(res(i_moving), mPFC_pred(i_moving));
    R2s(i,1+8) = fR2_calculation(res(i_all_off), mPFC_pred(i_all_off));
    R2s(i,2+8) = fR2_calculation(res(i_freezing_off), mPFC_pred(i_freezing_off));
    R2s(i,3+8) = fR2_calculation(res(i_stay_off), mPFC_pred(i_stay_off));
    R2s(i,4+8) = fR2_calculation(res(i_moving_off), mPFC_pred(i_moving_off));
    R2s(i,1+16) = fR2_calculation(res(i_all_on), mPFC_pred(i_all_on));
    R2s(i,2+16) = fR2_calculation(res(i_freezing_on), mPFC_pred(i_freezing_on));
    R2s(i,3+16) = fR2_calculation(res(i_stay_on), mPFC_pred(i_stay_on));
    R2s(i,4+16) = fR2_calculation(res(i_moving_on), mPFC_pred(i_moving_on));
    
    

    res = d(:,3);                                   % =3, vHPC calcium res
    [vHPC_k, vHPC_pred] = fRidge_Reg(beh, res, numBehaviors, preWindow, postWindow, plot_flag);
    vHPC_raw = res;
    R2s(i,5) = fR2_calculation(res, vHPC_pred);
    R2s(i,6) = fR2_calculation(res(i_freezing), vHPC_pred(i_freezing));
    R2s(i,7) = fR2_calculation(res(i_stay), vHPC_pred(i_stay));
    R2s(i,8) = fR2_calculation(res(i_moving), vHPC_pred(i_moving));
    R2s(i,5+8) = fR2_calculation(res(i_all_off), vHPC_pred(i_all_off));
    R2s(i,6+8) = fR2_calculation(res(i_freezing_off), vHPC_pred(i_freezing_off));
    R2s(i,7+8) = fR2_calculation(res(i_stay_off), vHPC_pred(i_stay_off));
    R2s(i,8+8) = fR2_calculation(res(i_moving_off), vHPC_pred(i_moving_off));
    R2s(i,5+16) = fR2_calculation(res(i_all_on), vHPC_pred(i_all_on));
    R2s(i,6+16) = fR2_calculation(res(i_freezing_on), vHPC_pred(i_freezing_on));
    R2s(i,7+16) = fR2_calculation(res(i_stay_on), vHPC_pred(i_stay_on));
    R2s(i,8+16) = fR2_calculation(res(i_moving_on), vHPC_pred(i_moving_on));
    
    
    mPFC_ks = cat(1, mPFC_ks, mPFC_k);
    mPFC_preds = cat(1, mPFC_preds, mPFC_pred');
    mPFC_raws = cat(1, mPFC_raws, mPFC_raw');

    vHPC_ks = cat(1, vHPC_ks, vHPC_k);
    vHPC_preds = cat(1, vHPC_preds, vHPC_pred');
    vHPC_raws = cat(1, vHPC_raws, vHPC_raw');
        
    beh2=zeros(1,28800);
    fl = size(out_f,1);
    for u = 1:fl
        if out_f(u,3) > thre
            beh2(out_f(u,1):out_f(u,2)) = 5;
        end;
    end;
    i0 = stages(2) + 1;
    i1 = stages(3);
    iit = find(beh2(i0:i1) > 0)+i0-1;
    beh2(iit) = beh2(iit)+1;
    i0 = stages(4) + 1;
    i1 = stages(5);
    iit = find(beh2(i0:i1) > 0)+i0-1;
    beh2(iit) = beh2(iit)+1;

    Freezing_ratio(i,1) = length(find(beh2 == 5))/((stages(2)-stages(1))+(stages(4)-stages(3)));
    Freezing_ratio(i,2) = length(find(beh2 == 6))/((stages(3)-stages(2))+(stages(5)-stages(4)));
end;    

