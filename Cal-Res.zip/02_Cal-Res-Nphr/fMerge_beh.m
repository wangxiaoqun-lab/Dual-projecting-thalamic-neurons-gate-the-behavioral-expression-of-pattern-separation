function  ds_beh = fMerge_beh(d_beh,d_beh2); 

ds_beh = cat(1, d_beh, d_beh2);
[temp, i] = sort(ds_beh(:,1));
ds_beh = ds_beh(i,:);

