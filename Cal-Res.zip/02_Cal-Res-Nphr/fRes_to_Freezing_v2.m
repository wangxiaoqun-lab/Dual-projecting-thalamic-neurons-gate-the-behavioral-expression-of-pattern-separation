function [mPFC_rs, mPFC_avgs, vHPC_rs, vHPC_avgs] = fRes_to_Freezing_v2(path_in, beh_type, beh_thre, flag_start_end)
freq = 40;

ch_beh = 5;                    

time0 = 1;
time1 = 12*60*freq;

fns = dir([path_in,'_*.xlsx']);
fnn = size(fns,1);

mPFC_rs = [];
mPFC_avgs = [];
vHPC_rs = [];
vHPC_avgs = [];

for i = 1:fnn    

    fn = fns(i).name;
    d = xlsread([path_in,fn]);

    st0 = [];
    
    ch_sig = 1;
    [mPFC_r0, mPFC_r0_avg, ...
        mPFC_du0, mPFC_beh_i0, ...
        mPFC_i_up,mPFC_i_down, ...
        mPFC_behf] = fGet_CalResToBeh_v2(d, ch_sig, ch_beh, beh_type, beh_thre, time0, time1, st0, flag_start_end);

    ch_sig = 5;
    [vHPC_r0, vHPC_r0_avg, ...
        vHPC_du0, vHPC_beh_i0, ...
        vHPC_i_up,vHPC_i_down, ...
        vHPC_behf] = fGet_CalResToBeh_v2(d, ch_sig, ch_beh, beh_type, beh_thre, time0, time1, st0, flag_start_end);
    
    mPFC_rs = cat(1, mPFC_rs, mPFC_r0);
    mPFC_avgs = cat(1, mPFC_avgs, mPFC_r0_avg);
    vHPC_rs = cat(1, vHPC_rs, vHPC_r0);
    vHPC_avgs = cat(1, vHPC_avgs, vHPC_r0_avg);  
end;
