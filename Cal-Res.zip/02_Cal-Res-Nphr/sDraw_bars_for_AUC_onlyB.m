ww = [200:280];
figure('Position',[100,100,800,800])
myColor = [1 1 1 1 2 2 2 2];
myAlpha = [1 0.5 1 0.5 1 0.5 1 0.5];
bx = [1 2 3 4 5 6 7 8];
MS = 160;
for i = 3
     % mPFC A 
    hold on
    ii = [i*2-1:numBehaviors:fnn_ca*numBehaviors];
    mpfc_a1 = mean(mPFC_ks_ca(ii,ww)')';  
    ii = [i*2:numBehaviors:fnn_ca*numBehaviors];
    mpfc_a2 = mean(mPFC_ks_ca(ii,ww)')';
    
    % mPFC B
    ii = [i*2-1:numBehaviors:fnn_cb*numBehaviors];
    mpfc_b1 = mean(mPFC_ks_cb(ii,ww)')';
    ii = [i*2:numBehaviors:fnn_cb*numBehaviors];
    mpfc_b2 = mean(mPFC_ks_cb(ii,ww)')';  

    % vHPC A
    ii = [i*2-1:numBehaviors:fnn_ca*numBehaviors];    
    vhpc_a1 = mean(vHPC_ks_ca(ii,ww)')';   
    ii = [i*2:numBehaviors:fnn_ca*numBehaviors];
    vhpc_a2 = mean(vHPC_ks_ca(ii,ww)')';

    % vHPC B
    ii = [i*2-1:numBehaviors:fnn_cb*numBehaviors];
    vhpc_b1 = mean(vHPC_ks_cb(ii,ww)')';
    ii = [i*2:numBehaviors:fnn_cb*numBehaviors];
    vhpc_b2 = mean(vHPC_ks_cb(ii,ww)')';
    
    subplot(2,2,i);
    hold on
    aucs = [mpfc_a1,mpfc_a2,vhpc_a1,vhpc_a2,mpfc_b1,mpfc_b2,vhpc_b1,vhpc_b2];
    auc_avg = mean(aucs);
    auc_se = std(aucs)/sqrt(fnn_ca);

    
    for j = 1:8
        scatter(bx(j),auc_avg(j),MS,'MarkerFaceColor',c(myColor(j),:),'MarkerEdgeColor','none','MarkerFaceAlpha',myAlpha(j));
        if mod(j,2) == 0
            plot([bx(j-1),bx(j)], [auc_avg(j-1),auc_avg(j)], 'color', c(myColor(j),:));
            [hh,pp] = ttest(aucs(:,j-1),aucs(:,j));
            text(bx(j-1),0.45,num2str(pp));
            ppp(j/2) = pp;
        end;
    end;
    

    e = errorbar(bx,auc_avg,auc_se,'LineStyle','none');
    e.CapSize = 0;
    e.Color = 'Black';
    hold off
    axis([4.5,8.5,-0.2,0.4]);
    
end