
clear;
c = colormap("lines");
tic
numBehaviors = 8;      

preWindow = 200;       
postWindow = 200;      
plot_flag = false;
freq  = 40;
freezing_thre = 1*freq;                    

path_in = 'TrOnOff_CG_A_off_v4\';
path_in2 = 'TrOnOff_CG_A_on_v4\';
[mPFC_ks_ca, mPFC_preds_ca, mPFC_raws_ca, vHPC_ks_ca, vHPC_preds_ca, vHPC_raws_ca, fnn_ca, frr_ca,R2_ca] = fKernal_Predict_v6_NewS_4ER2(path_in, path_in2, numBehaviors, preWindow, postWindow, plot_flag, 1);          %   1 == Recall A
path_in = 'TrOnOff_CG_B_off_v4\';
path_in2 = 'TrOnOff_CG_B_on_v4\';
[mPFC_ks_cb, mPFC_preds_cb, mPFC_raws_cb, vHPC_ks_cb, vHPC_preds_cb, vHPC_raws_cb, fnn_cb, frr_cb,R2_cb] = fKernal_Predict_v6_NewS_4ER2(path_in, path_in2, numBehaviors, preWindow, postWindow, plot_flag, 2);          %   2 == Recall B

toc

%%
figure('Position',[50,50,1000,800])
txy_flag = false;
txy = [-0.7 0.7; -0.7 0.7; -0.3 0.3; -0.3,0.3; ...
    -2 4; -2 4; -1 0.8; -1 0.8; ...
    -4 2; -4 2; -1 0.8; -1 0.8; ...
    -0.5 0.7; -0.5 0.7; -0.3 0.3; -0.3 0.3; ...
    -0.3 1; -0.3 1; -0.4 0.5; -0.4 0.5; ...
    -0.3 1; -0.3 1; -0.4 0.5; -0.4 0.5; ...
    -1.3 0.7; -1.3 0.7; -1 1; -1 1];
n_2 = numBehaviors/2;

for i = 1:n_2
    
    % mPFC A 
    subplot(n_2,4,i*4-3)
    hold on
    ii = [i*2-1:numBehaviors:fnn_ca*numBehaviors];
    plot(mean(mPFC_ks_ca(ii,:)),'LineWidth',1,'Color',c(1,:));
    [avg0,sd0,se0,xx,yy] = fPatch_parameters(mPFC_ks_ca(ii,:),preWindow,postWindow);
    patch(xx,yy,c(1,:),'EdgeColor','none','FaceAlpha',0.3);

    ii = [i*2:numBehaviors:fnn_ca*numBehaviors];
    plot(mean(mPFC_ks_ca(ii,:)),'LineWidth',2,'Color',c(1,:));
    [avg0,sd0,se0,xx,yy] = fPatch_parameters(mPFC_ks_ca(ii,:),preWindow,postWindow);
    patch(xx,yy,c(1,:),'EdgeColor','none','FaceAlpha',0.3);
    
   
    hold off
    if i == numBehaviors xlabel('Time relative to behavior onset (frames)'); end;
    ylabel('Ca response');
    title(['mPFC A' num2str(i) ' kernel']);
    xlim([0,preWindow+1+postWindow])
    if txy_flag == true ylim(txy(i*4-3,:)); end;

    
    % mPFC B
    subplot(n_2,4,i*4-1)
    hold on    
    
    ii = [i*2-1:numBehaviors:fnn_cb*numBehaviors];
    plot(mean(mPFC_ks_cb(ii,:)),'Linewidth',1,'Color',c(2,:));
    [avg0,sd0,se0,xx,yy] = fPatch_parameters(mPFC_ks_cb(ii,:),preWindow,postWindow);
    patch(xx,yy,c(2,:),'EdgeColor','none','FaceAlpha',0.3);
    
    ii = [i*2:numBehaviors:fnn_cb*numBehaviors];
    plot(mean(mPFC_ks_cb(ii,:)),'Linewidth',2,'Color',c(2,:));
    [avg0,sd0,se0,xx,yy] = fPatch_parameters(mPFC_ks_cb(ii,:),preWindow,postWindow);
    patch(xx,yy,c(2,:),'EdgeColor','none','FaceAlpha',0.3);
        
    hold off
    if i == numBehaviors xlabel('Time relative to behavior onset (frames)'); end;
    ylabel('Ca response');
    title(['mPFC B' num2str(i) ' kernel']);
    xlim([0,preWindow+1+postWindow])
    if txy_flag == true ylim(txy(i*4-1,:)); end;

    

    % vHPC A
    subplot(n_2,4,i*4-2)
    hold on
    ii = [i*2-1:numBehaviors:fnn_ca*numBehaviors];
    plot(mean(vHPC_ks_ca(ii,:)),'LineWidth',1,'Color',c(1,:));
    [avg0,sd0,se0,xx,yy] = fPatch_parameters(vHPC_ks_ca(ii,:),preWindow,postWindow);
    patch(xx,yy,c(1,:),'EdgeColor','none','FaceAlpha',0.3);

     ii = [i*2:numBehaviors:fnn_ca*numBehaviors];
    plot(mean(vHPC_ks_ca(ii,:)),'LineWidth',2,'Color',c(1,:));
    [avg0,sd0,se0,xx,yy] = fPatch_parameters(vHPC_ks_ca(ii,:),preWindow,postWindow);
    patch(xx,yy,c(1,:),'EdgeColor','none','FaceAlpha',0.3);   
    
    hold off
    if i == numBehaviors xlabel('Time relative to behavior onset (frames)'); end;
    title(['vHPC A' num2str(i) ' kernel']);
    xlim([0,preWindow+1+postWindow])
    if txy_flag == true ylim(txy(i*4-2,:)); end;
    

    % vHPC B
    subplot(n_2,4,i*4)
    hold on
    
    ii = [i*2-1:numBehaviors:fnn_cb*numBehaviors];
    plot(mean(vHPC_ks_cb(ii,:)),'LineWidth',1,'Color',c(2,:));
    [avg0,sd0,se0,xx,yy] = fPatch_parameters(vHPC_ks_cb(ii,:),preWindow,postWindow);
    patch(xx,yy,c(2,:),'EdgeColor','none','FaceAlpha',0.3);

    ii = [i*2:numBehaviors:fnn_cb*numBehaviors];
    plot(mean(vHPC_ks_cb(ii,:)),'LineWidth',2,'Color',c(2,:));
    [avg0,sd0,se0,xx,yy] = fPatch_parameters(vHPC_ks_cb(ii,:),preWindow,postWindow);
    patch(xx,yy,c(2,:),'EdgeColor','none','FaceAlpha',0.3);    
    
   
    hold off
    if i == numBehaviors xlabel('Time relative to behavior onset (frames)'); end;
    title(['vHPC B' num2str(i) ' kernel']);
    xlim([0,preWindow+1+postWindow])
    if txy_flag == true ylim(txy(i*4,:)); end;
    
end

%% 

figure('Position',[100,100,800,800])
axy = [-0.5,1,0,1.5];
MS = 120;
mPFC_A_xx = [200:280];
vHPC_A_xx = [200:280];
mPFC_B_xx = [200:280];
vHPC_B_xx = [200:280];

%
% vHPC_B
mark_i = 5;
peak_i = 300;

ii0_cb = [mark_i:numBehaviors:fnn_cb*numBehaviors];
x0_cb = mean(vHPC_ks_cb(ii0_cb,vHPC_B_xx)')';

ii0_gb = [mark_i+1:numBehaviors:fnn_cb*numBehaviors];
x0_gb = mean(vHPC_ks_cb(ii0_gb,vHPC_B_xx)')';


x0 = [x0_cb', x0_gb'];
y0 = [frr_cb(:,1)', frr_cb(:,2)'];

xx = x0;
yy = y0;

x_fit = [-5,12];
[p,S,mu] = polyfit(xx,yy,1);
p = polyfit(xx,yy,1);
[y_fit, delta] = polyval(p,x_fit,S);
[rsq,rsq_adj] = fCalculate_Rs(xx,yy,p,S);

AB_color = c(2,:);
subplot(2,2,4)
hold on
scatter(x0_cb', frr_cb(:,1)', MS, ...
         'MarkerFaceColor',AB_color,'MarkerEdgeColor','none');%,'MarkerFaceAlpha',0.7);
scatter(x0_gb', frr_cb(:,2)', MS, ...
         'MarkerFaceColor',AB_color,'MarkerEdgeColor','none','MarkerFaceAlpha',0.5);


plot(x_fit,y_fit,'linewidth',1,'color',AB_color);
plot(x_fit,y_fit+2*delta,'linewidth',1,'color',AB_color);
plot(x_fit,y_fit-2*delta,'linewidth',1,'color',AB_color);
text(0,0.6,['R^2 = ',num2str(rsq)]);
text(0,0.5,['Adjusted R^2 = ',num2str(rsq_adj)]);
axis(axy);
hold off
title('vHPC Recall B');


%
% vHPC_A
mark_i = 5;
peak_i = 190;   

ii0_ca = [mark_i:numBehaviors:fnn_ca*numBehaviors];
x0_ca = mean(vHPC_ks_ca(ii0_ca,vHPC_A_xx)')';
ii0_ga = [mark_i+1:numBehaviors:fnn_ca*numBehaviors];
x0_ga = mean(vHPC_ks_ca(ii0_ga,vHPC_A_xx)')';
x0 = [x0_ca', x0_ga'];
y0 = [frr_ca(:,1)', frr_ca(:,2)'];

xx = x0;
yy = y0;

x_fit = [-5,12];
[p,S,mu] = polyfit(xx,yy,1);
p = polyfit(xx,yy,1);
[y_fit, delta] = polyval(p,x_fit,S);
[rsq,rsq_adj] = fCalculate_Rs(xx,yy,p,S);

AB_color = c(1,:);
subplot(2,2,2);
hold on
scatter(x0_ca', frr_ca(:,1)', MS, ...
         'MarkerFaceColor',AB_color,'MarkerEdgeColor','none');
scatter(x0_ga', frr_ca(:,2)', MS, ...
         'MarkerFaceColor',AB_color,'MarkerEdgeColor','none','MarkerFaceAlpha',0.5);

plot(x_fit,y_fit,'linewidth',1,'color',AB_color);
plot(x_fit,y_fit+2*delta,'linewidth',1,'color',AB_color);
plot(x_fit,y_fit-2*delta,'linewidth',1,'color',AB_color);
text(0,0.6,['R^2 = ',num2str(rsq)]);
text(0,0.5,['Adjusted R^2 = ',num2str(rsq_adj)]);
axis(axy);
hold off
title('vHPC Recall A');


%
% mPFC_A
mark_i = 5;
peak_i = 190;

ii0_ca = [mark_i:numBehaviors:fnn_ca*numBehaviors];
x0_ca = mean(mPFC_ks_ca(ii0_ca,mPFC_A_xx)')';
ii0_ga = [mark_i+1:numBehaviors:fnn_ca*numBehaviors];
x0_ga = mean(mPFC_ks_ca(ii0_ga,mPFC_A_xx)')';
x0 = [x0_ca', x0_ga'];
y0 = [frr_ca(:,1)', frr_ca(:,2)'];
xx = x0;
yy = y0;

x_fit = [-5,12];
[p,S,mu] = polyfit(xx,yy,1);
p = polyfit(xx,yy,1);
[y_fit, delta] = polyval(p,x_fit,S);
[rsq,rsq_adj] = fCalculate_Rs(xx,yy,p,S);

AB_color = c(1,:);
subplot(2,2,1);
hold on
scatter(x0_ca', frr_ca(:,1)', MS, ...
         'MarkerFaceColor',AB_color,'MarkerEdgeColor','none');%,'MarkerFaceAlpha',0.7);
scatter(x0_ga', frr_ca(:,2)', MS, ...
         'MarkerFaceColor',AB_color,'MarkerEdgeColor','none','MarkerFaceAlpha',0.5);



plot(x_fit,y_fit,'linewidth',1,'color',AB_color);
plot(x_fit,y_fit+2*delta,'linewidth',1,'color',AB_color);
plot(x_fit,y_fit-2*delta,'linewidth',1,'color',AB_color);
text(0,0.6,['R^2 = ',num2str(rsq)]);
text(0,0.5,['Adjusted R^2 = ',num2str(rsq_adj)]);
axis(axy);
hold off
    
title('mPFC Recall A');
    
%
% mPFC_B
mark_i = 5;
peak_i = 200;

ii0_cb = [mark_i:numBehaviors:fnn_cb*numBehaviors];
x0_cb = mean(mPFC_ks_cb(ii0_cb,mPFC_B_xx)')';
ii0_gb = [mark_i+1:numBehaviors:fnn_cb*numBehaviors];
x0_gb = mean(mPFC_ks_cb(ii0_gb,mPFC_B_xx)')';
x0 = [x0_cb', x0_gb'];
y0 = [frr_cb(:,1)', frr_cb(:,2)'];   
xx = x0;
yy = y0;

x_fit = [-5,12];
[p,S,mu] = polyfit(xx,yy,1);
p = polyfit(xx,yy,1);
[y_fit, delta] = polyval(p,x_fit,S);
[rsq,rsq_adj] = fCalculate_Rs(xx,yy,p,S);

AB_color = c(2,:);
subplot(2,2,3)
hold on
scatter(x0_cb', frr_cb(:,1)', MS, ...
         'MarkerFaceColor',AB_color,'MarkerEdgeColor','none');%,'MarkerFaceAlpha',0.7);
scatter(x0_gb', frr_cb(:,2)', MS, ...
         'MarkerFaceColor',AB_color,'MarkerEdgeColor','none','MarkerFaceAlpha',0.5);

plot(x_fit,y_fit,'linewidth',1,'color',AB_color);
plot(x_fit,y_fit+2*delta,'linewidth',1,'color',AB_color);
plot(x_fit,y_fit-2*delta,'linewidth',1,'color',AB_color);
text(-0.2,0.6,['R^2 = ',num2str(rsq)]);
text(-0.2,0.5,['Adjusted R^2 = ',num2str(rsq_adj)]);
axis(axy);
hold off
    
title('mPFC Recall B');