# Installation

The FPA package (https://github.com/leomol/FPA) needs to be installed in advance.